/**
 * ZAFANA SNACK - Client Interactivity & Animation Engine
 * Tagline: "Teman Ngemil, Teman Bahagia!"
 */

document.addEventListener('DOMContentLoaded', function () {
  // ====================================================
  // 1. STICKY NAVBAR SHADOW ON SCROLL
  // ====================================================
  const navbarWrapper = document.querySelector('.navbar-wrapper');
  if (navbarWrapper) {
    window.addEventListener('scroll', function () {
      if (window.scrollY > 20) {
        navbarWrapper.style.boxShadow = '0 6px 20px rgba(15, 23, 42, 0.08)';
      } else {
        navbarWrapper.style.boxShadow = '0 4px 16px rgba(15, 23, 42, 0.05)';
      }
    }, { passive: true });
  }

  // ====================================================
  // 2. MOBILE HAMBURGER MENU TOGGLE
  // ====================================================
  const menuToggle = document.getElementById('menuToggle');
  const navMenu = document.getElementById('navMenu');

  if (menuToggle && navMenu) {
    menuToggle.addEventListener('click', function (e) {
      e.stopPropagation();
      navMenu.classList.toggle('show');
    });

    document.addEventListener('click', function (e) {
      if (!navMenu.contains(e.target) && !menuToggle.contains(e.target)) {
        navMenu.classList.remove('show');
      }
    });
  }

  // ====================================================
  // 3. USER PROFILE DROPDOWN (RINGKAS & ELEGAN)
  // ====================================================
  const userMenuToggle = document.getElementById('userMenuToggle');
  const userDropdownMenu = document.getElementById('userDropdownMenu');
  const userDropdownWrapper = document.getElementById('userDropdownWrapper');

  if (userMenuToggle && userDropdownMenu) {
    userMenuToggle.addEventListener('click', function (e) {
      e.stopPropagation();
      const isOpen = userDropdownMenu.classList.contains('show');
      if (isOpen) {
        userDropdownMenu.classList.remove('show');
        if (userDropdownWrapper) userDropdownWrapper.classList.remove('active');
      } else {
        userDropdownMenu.classList.add('show');
        if (userDropdownWrapper) userDropdownWrapper.classList.add('active');
      }
    });

    // Tutup saat klik di luar dropdown
    document.addEventListener('click', function (e) {
      if (!userDropdownMenu.contains(e.target) && !userMenuToggle.contains(e.target)) {
        userDropdownMenu.classList.remove('show');
        if (userDropdownWrapper) userDropdownWrapper.classList.remove('active');
      }
    });
  }

  // ====================================================
  // 4. FLOATING TOAST NOTIFICATION
  // ====================================================
  function showToast(message, type = 'success') {
    const container = document.getElementById('toastContainer');
    if (!container) return;

    const toast = document.createElement('div');
    toast.className = `toast-item toast-${type}`;
    
    let icon = 'fa-circle-check';
    if (type === 'error') icon = 'fa-circle-exclamation';
    if (type === 'info') icon = 'fa-circle-info';

    toast.innerHTML = `
      <i class="fa-solid ${icon} toast-icon"></i>
      <div>${message}</div>
    `;

    container.appendChild(toast);

    setTimeout(() => {
      toast.style.opacity = '0';
      toast.style.transform = 'translateY(12px)';
      toast.style.transition = 'all 0.3s ease';
      setTimeout(() => toast.remove(), 300);
    }, 3200);
  }

  // ====================================================
  // 5. SLIDE-OUT DRAWER KERANJANG BELANJA (AJAX)
  // ====================================================
  const cartBackdrop = document.getElementById('cartBackdrop');
  const cartDrawer = document.getElementById('cartDrawer');
  const openCartDrawerBtn = document.getElementById('openCartDrawerBtn');
  const closeCartDrawerBtn = document.getElementById('closeCartDrawer');
  const cartDrawerItems = document.getElementById('cartDrawerItems');
  const drawerTotalPrice = document.getElementById('drawerTotalPrice');
  const drawerItemCount = document.getElementById('drawerItemCount');
  const navCartCount = document.getElementById('navCartCount');
  const shippingProgressFill = document.getElementById('shippingProgressFill');
  const shippingProgressText = document.getElementById('shippingProgressText');
  const cartDrawerFooter = document.getElementById('cartDrawerFooter');

  function openDrawer() {
    if (cartDrawer && cartBackdrop) {
      cartDrawer.classList.add('open');
      cartBackdrop.classList.add('show');
      cartDrawer.setAttribute('aria-hidden', 'false');
      cartBackdrop.setAttribute('aria-hidden', 'false');
      document.body.style.overflow = 'hidden'; // cegah scroll body saat drawer aktif
      loadCartData();
    }
  }

  function closeDrawer() {
    if (cartDrawer && cartBackdrop) {
      cartDrawer.classList.remove('open');
      cartBackdrop.classList.remove('show');
      cartDrawer.setAttribute('aria-hidden', 'true');
      cartBackdrop.setAttribute('aria-hidden', 'true');
      document.body.style.overflow = '';
    }
  }

  if (openCartDrawerBtn) {
    openCartDrawerBtn.addEventListener('click', openDrawer);
  }

  if (closeCartDrawerBtn) {
    closeCartDrawerBtn.addEventListener('click', closeDrawer);
  }

  if (cartBackdrop) {
    cartBackdrop.addEventListener('click', closeDrawer);
  }

  // Tutup dengan Tombol Escape di Keyboard
  document.addEventListener('keydown', function (e) {
    if (e.key === 'Escape') {
      closeDrawer();
      if (userDropdownMenu) {
        userDropdownMenu.classList.remove('show');
        if (userDropdownWrapper) userDropdownWrapper.classList.remove('active');
      }
    }
  });

  // Load Data Keranjang via AJAX
  function loadCartData() {
    const baseUrl = window.location.origin + '/zafanasnack/';
    fetch(baseUrl + 'api/cart.php?action=get')
      .then(res => res.json())
      .then(data => {
        if (!data.success) return;

        // Update badge dan total harga
        if (navCartCount) navCartCount.textContent = data.total_items;
        if (drawerItemCount) drawerItemCount.textContent = data.total_items + ' bungkus';
        if (drawerTotalPrice) drawerTotalPrice.textContent = data.total_price_formatted;

        // Progress Bebas Ongkir (Target Rp 60.000)
        const targetFree = 60000;
        const percent = Math.min(100, Math.round((data.total_price / targetFree) * 100));
        if (shippingProgressFill) shippingProgressFill.style.width = percent + '%';

        if (shippingProgressText) {
          if (data.total_price >= targetFree && data.total_items > 0) {
            shippingProgressText.innerHTML = '<i class="fa-solid fa-gift text-success"></i> Selamat! Kamu dapat Kuota Bebas Ongkir!';
          } else {
            const sisa = Math.max(0, targetFree - data.total_price);
            shippingProgressText.innerHTML = `<i class="fa-solid fa-truck-fast text-blue"></i> Tambah Rp ${sisa.toLocaleString('id-ID')} lagi untuk Bebas Ongkir!`;
          }
        }

        // Render Item Produk
        if (!cartDrawerItems) return;

        if (data.items.length === 0) {
          cartDrawerItems.innerHTML = `
            <div class="drawer-empty-state">
              <div class="drawer-empty-icon">
                <i class="fa-solid fa-cart-shopping"></i>
              </div>
              <h4>Keranjang Belanja Kosong</h4>
              <p>Belum ada camilan yang kamu pilih. Yuk, cari snack renyah favoritmu sekarang!</p>
              <a href="${baseUrl}katalog.php" class="btn btn-sm btn-primary" style="margin-top: 15px;" onclick="document.getElementById('cartBackdrop').click()">
                <i class="fa-solid fa-cookie-bite"></i> Jelajahi Katalog Snack
              </a>
            </div>
          `;
          if (cartDrawerFooter) cartDrawerFooter.style.display = 'none';
        } else {
          if (cartDrawerFooter) cartDrawerFooter.style.display = 'block';

          let html = '';
          data.items.forEach(item => {
            html += `
              <div class="drawer-item" data-id="${item.id_produk}">
                <div class="drawer-item-thumb">
                  <img src="${item.foto_url || (baseUrl + 'assets/images/products/' + (item.foto || 'default_snack.jpg'))}" 
                       alt="${item.nama_produk}" 
                       loading="lazy"
                       onerror="this.onerror=null; this.src='${baseUrl}assets/images/products/default_snack.jpg'">
                </div>
                <div class="drawer-item-info">
                  <h4 class="drawer-item-title">${item.nama_produk}</h4>
                  <div class="drawer-item-price">${item.harga_formatted}</div>
                  
                  <div class="drawer-item-actions">
                    <div class="drawer-qty-control">
                      <button type="button" class="drawer-qty-btn btn-qty-minus" data-id="${item.id_produk}" data-qty="${item.qty}">-</button>
                      <span class="drawer-qty-num">${item.qty}</span>
                      <button type="button" class="drawer-qty-btn btn-qty-plus" data-id="${item.id_produk}" data-qty="${item.qty}" data-max="${item.stok}">+</button>
                    </div>
                    <button type="button" class="drawer-item-delete btn-remove-item" data-id="${item.id_produk}" title="Hapus Item">
                      <i class="fa-regular fa-trash-can"></i>
                    </button>
                  </div>
                </div>
              </div>
            `;
          });
          cartDrawerItems.innerHTML = html;
        }
      })
      .catch(err => console.error('Error fetching cart:', err));
  }

  // Event Delegation untuk Tombol Minus, Plus, Hapus di Keranjang
  if (cartDrawerItems) {
    cartDrawerItems.addEventListener('click', function (e) {
      const minusBtn = e.target.closest('.btn-qty-minus');
      if (minusBtn) {
        const id = minusBtn.getAttribute('data-id');
        const qty = parseInt(minusBtn.getAttribute('data-qty')) - 1;
        updateCartItem(id, qty);
        return;
      }

      const plusBtn = e.target.closest('.btn-qty-plus');
      if (plusBtn) {
        const id = plusBtn.getAttribute('data-id');
        const qty = parseInt(plusBtn.getAttribute('data-qty')) + 1;
        const max = parseInt(plusBtn.getAttribute('data-max')) || 999;
        if (qty > max) {
          showToast(`Maksimal stok tersedia adalah ${max} bungkus`, 'error');
          return;
        }
        updateCartItem(id, qty);
        return;
      }

      const removeBtn = e.target.closest('.btn-remove-item');
      if (removeBtn) {
        const id = removeBtn.getAttribute('data-id');
        removeCartItem(id);
        return;
      }
    });
  }

  function updateCartItem(id, qty) {
    const baseUrl = window.location.origin + '/zafanasnack/';
    const formData = new FormData();
    formData.append('action', 'update');
    formData.append('id_produk', id);
    formData.append('qty', qty);

    fetch(baseUrl + 'api/cart.php', { method: 'POST', body: formData })
      .then(res => res.json())
      .then(data => {
        if (data.success) {
          loadCartData();
        } else {
          showToast(data.message, 'error');
        }
      });
  }

  function removeCartItem(id) {
    const baseUrl = window.location.origin + '/zafanasnack/';
    const formData = new FormData();
    formData.append('action', 'remove');
    formData.append('id_produk', id);

    fetch(baseUrl + 'api/cart.php', { method: 'POST', body: formData })
      .then(res => res.json())
      .then(data => {
        if (data.success) {
          showToast(data.message, 'info');
          loadCartData();
        }
      });
  }

  // ====================================================
  // 6. AJAX ADD TO CART DARI TOMBOL PRODUK
  // ====================================================
  document.addEventListener('click', function (e) {
    const addBtn = e.target.closest('.btn-quick-add, .btn-submit-cart');
    if (addBtn) {
      e.preventDefault();
      const id = addBtn.getAttribute('data-id');
      const qtyInput = document.getElementById('detailQtyInput');
      const qty = qtyInput ? parseInt(qtyInput.value) : 1;

      const baseUrl = window.location.origin + '/zafanasnack/';
      const formData = new FormData();
      formData.append('action', 'add');
      formData.append('id_produk', id);
      formData.append('jumlah', qty);

      // Feedback animasi klik
      addBtn.style.transform = 'scale(0.92)';
      setTimeout(() => addBtn.style.transform = '', 150);

      fetch(baseUrl + 'api/cart.php', { method: 'POST', body: formData })
        .then(res => res.json())
        .then(data => {
          if (data.success) {
            showToast(data.message, 'success');
            if (navCartCount) navCartCount.textContent = data.total_items;
            openDrawer(); // Buka drawer cart dari sisi kanan secara mulus
          } else {
            showToast(data.message, 'error');
          }
        })
        .catch(err => {
          console.error(err);
          showToast('Koneksi terputus ke server.', 'error');
        });
    }
  });

  // ====================================================
  // 7. SCROLL ANIMASI INTERSECTION OBSERVER
  // ====================================================
  const prefersReducedMotion = window.matchMedia('(prefers-reduced-motion: reduce)').matches;

  if (!prefersReducedMotion && 'IntersectionObserver' in window) {
    const animateElements = document.querySelectorAll('.scroll-animate');

    // Auto-stagger delay untuk grid cards
    const gridContainers = document.querySelectorAll('.product-grid, .category-grid, .testimonials-grid');
    gridContainers.forEach(grid => {
      const items = grid.querySelectorAll('.scroll-animate');
      items.forEach((item, index) => {
        const delay = (index % 4) * 100; // 0ms, 100ms, 200ms, 300ms
        item.style.transitionDelay = `${delay}ms`;
      });
    });

    const observerOptions = {
      root: null,
      rootMargin: '0px 0px -40px 0px',
      threshold: 0.12
    };

    const scrollObserver = new IntersectionObserver((entries, observer) => {
      entries.forEach(entry => {
        if (entry.isIntersecting) {
          entry.target.classList.add('is-visible');
          observer.unobserve(entry.target); // Hanya animasi sekali
        }
      });
    }, observerOptions);

    animateElements.forEach(el => scrollObserver.observe(el));
  } else {
    // Fallback untuk browser lama atau reduced-motion
    document.querySelectorAll('.scroll-animate').forEach(el => el.classList.add('is-visible'));
  }

  // ====================================================
  // 8. LIVE SEARCH & SORTING DI HALAMAN KATALOG
  // ====================================================
  const liveSearchInput = document.getElementById('liveSearchInput');
  const catalogProductGrid = document.getElementById('catalogProductGrid');
  const sortSelect = document.getElementById('sortSelect');

  if (liveSearchInput && catalogProductGrid) {
    liveSearchInput.addEventListener('input', function () {
      const query = liveSearchInput.value.toLowerCase().trim();
      const cards = catalogProductGrid.querySelectorAll('.product-card');
      let count = 0;

      cards.forEach(card => {
        const title = (card.getAttribute('data-title') || '').toLowerCase();
        const cat = (card.getAttribute('data-category') || '').toLowerCase();

        if (title.includes(query) || cat.includes(query)) {
          card.style.display = '';
          count++;
        } else {
          card.style.display = 'none';
        }
      });

      const noResultBox = document.getElementById('noResultBox');
      if (noResultBox) {
        noResultBox.style.display = (count === 0) ? 'block' : 'none';
      }
    });
  }

  if (sortSelect && catalogProductGrid) {
    sortSelect.addEventListener('change', function () {
      const sortBy = sortSelect.value;
      const cards = Array.from(catalogProductGrid.querySelectorAll('.product-card'));

      cards.sort((a, b) => {
        const priceA = parseInt(a.getAttribute('data-price')) || 0;
        const priceB = parseInt(b.getAttribute('data-price')) || 0;
        const soldA = parseInt(a.getAttribute('data-sold')) || 0;
        const soldB = parseInt(b.getAttribute('data-sold')) || 0;
        const ratingA = parseFloat(a.getAttribute('data-rating')) || 0;
        const ratingB = parseFloat(b.getAttribute('data-rating')) || 0;

        if (sortBy === 'price_asc') return priceA - priceB;
        if (sortBy === 'price_desc') return priceB - priceA;
        if (sortBy === 'bestseller') return soldB - soldA;
        if (sortBy === 'rating') return ratingB - ratingA;
        return 0;
      });

      cards.forEach(card => {
        card.classList.add('is-visible');
        catalogProductGrid.appendChild(card);
      });
    });
  }

  // ====================================================
  // 9. DETAIL PRODUK QUANTITY COUNTER
  // ====================================================
  const detailQtyMinus = document.getElementById('detailQtyMinus');
  const detailQtyPlus = document.getElementById('detailQtyPlus');
  const detailQtyInput = document.getElementById('detailQtyInput');

  if (detailQtyMinus && detailQtyPlus && detailQtyInput) {
    detailQtyMinus.addEventListener('click', () => {
      let val = parseInt(detailQtyInput.value) || 1;
      if (val > 1) detailQtyInput.value = val - 1;
    });

    detailQtyPlus.addEventListener('click', () => {
      let val = parseInt(detailQtyInput.value) || 1;
      let max = parseInt(detailQtyInput.getAttribute('max')) || 999;
      if (val < max) detailQtyInput.value = val + 1;
    });
  }

  // ====================================================
  // 10. KONFIRMASI HAPUS
  // ====================================================
  const confirmDeletes = document.querySelectorAll('.btn-confirm-delete');
  confirmDeletes.forEach(btn => {
    btn.addEventListener('click', function (e) {
      if (!confirm('Apakah Anda yakin ingin melanjutkan tindakan ini?')) {
        e.preventDefault();
      }
    });
  });
});
