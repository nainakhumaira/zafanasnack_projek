<?php
/**
 * Koneksi Database ZAFANA SNACK
 * Portabel untuk Localhost XAMPP dan Server Web Hosting (cPanel / DirectAdmin / VPS)
 */

// Mulai session jika belum berjalan
if (session_status() === PHP_SESSION_NONE) {
    session_start();
}

// Konfigurasi Database (Mendukung Environment Variables atau file config eksternal)
$db_host = getenv('DB_HOST') ?: 'localhost';
$db_user = getenv('DB_USER') ?: 'root';
$db_pass = getenv('DB_PASS') !== false ? getenv('DB_PASS') : '';
$db_name = getenv('DB_NAME') ?: 'db_zafanasnack';

// Cek jika ada konfigurasi khusus hosting terpisah
if (file_exists(__DIR__ . '/database.hosting.php')) {
    require_once __DIR__ . '/database.hosting.php';
}

// Buat koneksi MySQLi
$koneksi = @mysqli_connect($db_host, $db_user, $db_pass, $db_name);

// Cek status koneksi
if (!$koneksi) {
    $error_msg = mysqli_connect_error();
    die("
    <div style='font-family: Arial, sans-serif; max-width: 650px; margin: 40px auto; padding: 25px; border-radius: 12px; background: #FEF2F2; border: 1px solid #FCA5A5; color: #991B1B;'>
        <h2 style='margin-top:0;'>⚠️ Gagal Terhubung ke Database MySQL</h2>
        <p>Aplikasi tidak dapat terhubung ke server database. Silakan periksa:</p>
        <ul style='line-height: 1.6;'>
            <li><strong>Di Hosting:</strong> Pastikan nama database, username database, dan password di <code>config/koneksi.php</code> sudah sesuai dengan konfigurasi cPanel MySQL.</li>
            <li><strong>Hak Akses Database:</strong> Pastikan user MySQL sudah dihubungkan ke database dengan hak akses <em>ALL PRIVILEGES</em>.</li>
            <li><strong>Di Localhost (XAMPP):</strong> Pastikan Apache & MySQL di XAMPP Control Panel sudah dalam status <em>Start</em>.</li>
        </ul>
        <p style='font-size: 13px; color: #7F1D1D; background: #FEE2E2; padding: 10px; border-radius: 6px; font-family: monospace;'>Error: " . htmlspecialchars($error_msg) . "</p>
    </div>
    ");
}

// Set karakter encoding ke utf8mb4 agar mendukung simbol & emoji
mysqli_set_charset($koneksi, "utf8mb4");

// Tentukan Base URL secara dinamis dan portabel (otomatis mengenali domain hosting maupun folder localhost)
if (!defined('BASE_URL')) {
    $env_url = getenv('APP_URL');
    if (!empty($env_url)) {
        define('BASE_URL', rtrim($env_url, '/') . '/');
    } else {
        $is_https = (!empty($_SERVER['HTTPS']) && $_SERVER['HTTPS'] !== 'off') || 
                    (isset($_SERVER['SERVER_PORT']) && $_SERVER['SERVER_PORT'] == 443) ||
                    (isset($_SERVER['HTTP_X_FORWARDED_PROTO']) && $_SERVER['HTTP_X_FORWARDED_PROTO'] === 'https');
        $protocol = $is_https ? "https://" : "http://";
        $host = $_SERVER['HTTP_HOST'] ?? 'localhost';

        $doc_root = isset($_SERVER['DOCUMENT_ROOT']) ? str_replace('\\', '/', realpath($_SERVER['DOCUMENT_ROOT']) ?: $_SERVER['DOCUMENT_ROOT']) : '';
        $proj_dir = str_replace('\\', '/', realpath(__DIR__ . '/..') ?: dirname(__DIR__));

        if (!empty($doc_root) && !empty($proj_dir) && strpos($proj_dir, $doc_root) === 0) {
            $subpath = trim(substr($proj_dir, strlen($doc_root)), '/');
            $base_path = ($subpath === '') ? '/' : '/' . $subpath . '/';
        } else {
            $uri = $_SERVER['REQUEST_URI'] ?? '';
            if (strpos($uri, '/zafanasnack/') !== false) {
                $base_path = '/zafanasnack/';
            } else {
                $base_path = '/';
            }
        }
        define('BASE_URL', $protocol . $host . $base_path);
    }
}

// Sinkronisasi skema kolom database secara aman & otomatis (tidak menghapus data lama)
if (!function_exists('ensure_database_schema')) {
    function ensure_database_schema($koneksi) {
        if (!$koneksi) return;
        static $already_synced = false;
        if ($already_synced) return;
        $already_synced = true;

        $check_col = @mysqli_query($koneksi, "SHOW COLUMNS FROM `produk` LIKE 'is_best_seller'");
        if ($check_col && mysqli_num_rows($check_col) === 0) {
            @mysqli_query($koneksi, "ALTER TABLE `produk` ADD COLUMN `harga_coret` INT DEFAULT 0 AFTER `harga`");
            @mysqli_query($koneksi, "ALTER TABLE `produk` ADD COLUMN `is_best_seller` TINYINT(1) DEFAULT 0 AFTER `foto`");
            @mysqli_query($koneksi, "ALTER TABLE `produk` ADD COLUMN `is_promo` TINYINT(1) DEFAULT 0 AFTER `is_best_seller`");
            @mysqli_query($koneksi, "ALTER TABLE `produk` ADD COLUMN `terjual` INT DEFAULT 0 AFTER `is_promo`");
            @mysqli_query($koneksi, "ALTER TABLE `produk` ADD COLUMN `rating` DECIMAL(2,1) DEFAULT 4.8 AFTER `terjual`");
        }

        $check_kat = @mysqli_query($koneksi, "SHOW COLUMNS FROM `kategori` LIKE 'ikon'");
        if ($check_kat && mysqli_num_rows($check_kat) === 0) {
            @mysqli_query($koneksi, "ALTER TABLE `kategori` ADD COLUMN `ikon` VARCHAR(50) DEFAULT 'fa-cookie' AFTER `slug`");
        }

        @mysqli_query($koneksi, "CREATE TABLE IF NOT EXISTS `kontak_pesan` (
          `id_pesan` INT AUTO_INCREMENT PRIMARY KEY,
          `nama` VARCHAR(100) NOT NULL,
          `email` VARCHAR(100) NOT NULL,
          `no_hp` VARCHAR(20) NOT NULL,
          `subjek` VARCHAR(150) NULL,
          `pesan` TEXT NOT NULL,
          `tanggal_kirim` TIMESTAMP DEFAULT CURRENT_TIMESTAMP
        ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4");

        // Tabel pengaturan toko dinamis
        @mysqli_query($koneksi, "CREATE TABLE IF NOT EXISTS `pengaturan` (
          `kunci` VARCHAR(50) NOT NULL PRIMARY KEY,
          `nilai` TEXT NOT NULL,
          `keterangan` VARCHAR(150) NULL,
          `updated_at` TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP
        ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4");

        $cek_set = @mysqli_query($koneksi, "SELECT COUNT(*) as cnt FROM `pengaturan`");
        $d_set = $cek_set ? mysqli_fetch_assoc($cek_set) : null;
        if (!$d_set || (int)$d_set['cnt'] === 0) {
            $default_settings = [
                'nama_toko' => ['ZAFANA SNACK', 'Nama resmi toko/brand'],
                'slogan' => ['Teman Ngemil, Teman Bahagia!', 'Slogan toko'],
                'alamat' => ['Jl. Simpang Sari No. 758', 'Alamat lengkap toko / rumah produksi'],
                'no_telepon' => ['+62 896-2461-4578', 'Nomor telepon toko berformat tampilan'],
                'no_whatsapp' => ['6289624614578', 'Nomor WhatsApp format internasional (tanpa + atau 0)'],
                'email_toko' => ['halo@zafanasnack.com', 'Alamat email resmi toko'],
                'jam_operasional' => ['Senin - Minggu: 08.00 - 21.00 WIB', 'Jam operasional dan pengiriman pesanan']
            ];
            foreach ($default_settings as $k => $v) {
                $k_esc = mysqli_real_escape_string($koneksi, $k);
                $v_esc = mysqli_real_escape_string($koneksi, $v[0]);
                $desc_esc = mysqli_real_escape_string($koneksi, $v[1]);
                @mysqli_query($koneksi, "INSERT IGNORE INTO `pengaturan` (`kunci`, `nilai`, `keterangan`) VALUES ('$k_esc', '$v_esc', '$desc_esc')");
            }
        }
    }
}
ensure_database_schema($koneksi);

// Sertakan file helper pembantu
require_once __DIR__ . '/helper.php';
