<?php
/**
 * Konfigurasi Tunggal Identitas & Pengaturan Toko ZAFANA SNACK
 * Terhubung langsung ke database MySQL tabel `pengaturan` sehingga Admin
 * dapat memperbaruinya sewaktu-waktu melalui Dashboard Admin (admin/pengaturan.php).
 */

global $koneksi;

$db_settings = [];
if (!empty($koneksi)) {
    try {
        $q_set = mysqli_query($koneksi, "SELECT `kunci`, `nilai` FROM `pengaturan`");
        if ($q_set) {
            while ($r = mysqli_fetch_assoc($q_set)) {
                $db_settings[$r['kunci']] = $r['nilai'];
            }
        }
    } catch (Throwable $e) {
        // Fallback jika tabel pengaturan belum dibuat atau sedang migrasi
        $db_settings = [];
    }
}

// Nilai default jika database belum tersedia
$store_name = $db_settings['nama_toko'] ?? 'ZAFANA SNACK';
$store_slogan = $db_settings['slogan'] ?? 'Teman Ngemil, Teman Bahagia!';
$store_address = $db_settings['alamat'] ?? 'Jl. Simpang Sari No. 758';
$store_phone = $db_settings['no_telepon'] ?? '+62 896-2461-4578';
$store_wa = $db_settings['no_whatsapp'] ?? '6289624614578';
$store_email = $db_settings['email_toko'] ?? 'halo@zafanasnack.com';
$store_hours = $db_settings['jam_operasional'] ?? 'Senin - Minggu: 08.00 - 21.00 WIB';

// Bersihkan nomor WhatsApp (hanya digit, awali 62)
$store_wa_clean = preg_replace('/[^\d]/', '', $store_wa);
if (str_starts_with($store_wa_clean, '0')) {
    $store_wa_clean = '62' . substr($store_wa_clean, 1);
}

// Nomor telepon mentah (misal: 089624614578)
$store_phone_raw = preg_replace('/[^\d]/', '', $store_phone);

if (!defined('STORE_NAME')) define('STORE_NAME', $store_name);
if (!defined('STORE_SLOGAN')) define('STORE_SLOGAN', $store_slogan);
if (!defined('STORE_ADDRESS')) define('STORE_ADDRESS', $store_address);
if (!defined('STORE_PHONE')) define('STORE_PHONE', $store_phone);
if (!defined('STORE_PHONE_RAW')) define('STORE_PHONE_RAW', $store_phone_raw);
if (!defined('STORE_EMAIL')) define('STORE_EMAIL', $store_email);
if (!defined('STORE_HOURS')) define('STORE_HOURS', $store_hours);
if (!defined('WA_STORE_NUMBER')) define('WA_STORE_NUMBER', $store_wa_clean);
if (!defined('WA_STORE_URL')) define('WA_STORE_URL', 'https://wa.me/' . $store_wa_clean);

/**
 * Helper untuk mengambil nilai pengaturan toko dinamis
 */
if (!function_exists('get_shop_setting')) {
    function get_shop_setting($key, $default = '') {
        global $koneksi;
        if (!empty($koneksi)) {
            try {
                $key_esc = mysqli_real_escape_string($koneksi, $key);
                $res = mysqli_query($koneksi, "SELECT nilai FROM pengaturan WHERE kunci = '$key_esc' LIMIT 1");
                if ($res && $row = mysqli_fetch_assoc($res)) {
                    return $row['nilai'];
                }
            } catch (Throwable $e) {
                return $default;
            }
        }
        return $default;
    }
}

/**
 * Helper untuk membuat URL chat WhatsApp resmi ZAFANA SNACK
 */
if (!function_exists('get_whatsapp_url')) {
    function get_whatsapp_url($custom_text = '') {
        $base = 'https://wa.me/' . WA_STORE_NUMBER;
        if (!empty($custom_text)) {
            return $base . '?text=' . urlencode($custom_text);
        }
        return $base;
    }
}
