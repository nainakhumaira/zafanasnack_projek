<?php
/**
 * Helper Functions ZAFANA SNACK
 * Kumpulan fungsi bantuan yang sering dipakai berulang-ulang
 */

// Format angka ke format mata uang Rupiah
if (!function_exists('rupiah')) {
    function rupiah($angka) {
        return "Rp " . number_format($angka, 0, ',', '.');
    }
}

// Konversi teks menjadi slug URL ramah SEO (contoh: "Keripik Singkong" -> "keripik-singkong")
if (!function_exists('slugify')) {
    function slugify($text) {
        $text = preg_replace('~[^\pL\d]+~u', '-', $text);
        $text = iconv('utf-8', 'us-ascii//TRANSLIT', $text);
        $text = preg_replace('~[^-\w]+~', '', $text);
        $text = trim($text, '-');
        $text = preg_replace('~-+~', '-', $text);
        $text = strtolower($text);
        return empty($text) ? 'n-a' : $text;
    }
}

// Cek apakah pengguna sudah login
if (!function_exists('is_logged_in')) {
    function is_logged_in() {
        return isset($_SESSION['user']) && !empty($_SESSION['user']['id_user']);
    }
}

// Cek apakah user yang login adalah admin
if (!function_exists('is_admin')) {
    function is_admin() {
        return is_logged_in() && ($_SESSION['user']['role'] ?? '') === 'admin';
    }
}

// Ambil data user yang sedang aktif
if (!function_exists('current_user')) {
    function current_user() {
        return $_SESSION['user'] ?? null;
    }
}

// Menampilkan pesan notifikasi (Flash message)
if (!function_exists('set_flash')) {
    function set_flash($tipe, $pesan) {
        $_SESSION['flash'] = [
            'tipe' => $tipe, // success, danger, warning, info
            'pesan' => $pesan
        ];
    }
}

if (!function_exists('get_flash')) {
    function get_flash() {
        if (isset($_SESSION['flash'])) {
            $flash = $_SESSION['flash'];
            unset($_SESSION['flash']);
            $tipe_class = $flash['tipe'] === 'success' ? 'alert-success' : 'alert-danger';
            return "<div class='alert {$tipe_class}'>{$flash['pesan']}</div>";
        }
        return '';
    }
}

// Menghitung total item di keranjang belanja
if (!function_exists('total_cart_items')) {
    function total_cart_items() {
        if (!isset($_SESSION['cart']) || empty($_SESSION['cart'])) {
            return 0;
        }
        $total = 0;
        foreach ($_SESSION['cart'] as $item) {
            $total += (int)($item['qty'] ?? 1);
        }
        return $total;
    }
}

// Helper untuk URL Foto Produk yang Bersih, Relatif, dan Fallback Otomatis
if (!function_exists('get_product_image_url')) {
    function get_product_image_url($foto) {
        $default_fallback = BASE_URL . 'assets/images/products/default_snack.jpg';
        if (empty($foto)) {
            return $default_fallback;
        }

        // Ambil hanya nama file bersih (menghapus path lokal C:\xampp\...)
        $clean_name = basename(str_replace(['\\', '/'], DIRECTORY_SEPARATOR, trim((string)$foto)));
        if (empty($clean_name) || $clean_name === '.' || $clean_name === '..') {
            return $default_fallback;
        }

        // 1. Cek folder uploads/produk/ terlebih dahulu
        $uploads_dir = dirname(__DIR__) . DIRECTORY_SEPARATOR . 'uploads' . DIRECTORY_SEPARATOR . 'produk' . DIRECTORY_SEPARATOR;
        if (file_exists($uploads_dir . $clean_name)) {
            return BASE_URL . 'uploads/produk/' . $clean_name;
        }

        // 2. Cek folder assets/images/products/
        $assets_dir = dirname(__DIR__) . DIRECTORY_SEPARATOR . 'assets' . DIRECTORY_SEPARATOR . 'images' . DIRECTORY_SEPARATOR . 'products' . DIRECTORY_SEPARATOR;

        // Jika foto berakhiran .svg, prioritaskan file foto asli .jpg jika ada
        if (str_ends_with(strtolower($clean_name), '.svg')) {
            $jpg_candidate = substr($clean_name, 0, -4) . '.jpg';
            if (file_exists($assets_dir . $jpg_candidate)) {
                return BASE_URL . 'assets/images/products/' . $jpg_candidate;
            }
        }

        // Cek apakah file foto fisik ada di folder assets produk
        if (file_exists($assets_dir . $clean_name)) {
            return BASE_URL . 'assets/images/products/' . $clean_name;
        }

        // Coba cek jika ada file .jpg dengan nama yang sama di assets
        $name_without_ext = pathinfo($clean_name, PATHINFO_FILENAME);
        if (file_exists($assets_dir . $name_without_ext . '.jpg')) {
            return BASE_URL . 'assets/images/products/' . $name_without_ext . '.jpg';
        }

        return $default_fallback;
    }
}

// Sertakan satu sumber konfigurasi identitas & pengaturan toko resmi
require_once __DIR__ . '/shop_info.php';

/**
 * Helper Unggah Gambar Produk ke folder uploads/produk/
 * Validasi MIME type asli, batas ukuran 5MB, format JPG, JPEG, PNG, WEBP,
 * dan menghasilkan nama file unik anti-collision serta aman dari script berbahaya.
 */
if (!function_exists('handle_product_image_upload')) {
    function handle_product_image_upload($file, &$error_msg = null) {
        $error_msg = null;
        if (!isset($file) || !is_array($file) || empty($file['name'])) {
            return null; // Tidak ada file yang diunggah (bukan error jika opsional saat edit)
        }

        if ($file['error'] !== UPLOAD_ERR_OK) {
            if ($file['error'] === UPLOAD_ERR_INI_SIZE || $file['error'] === UPLOAD_ERR_FORM_SIZE) {
                $error_msg = 'Ukuran file foto melebihi batas maksimal 5 MB.';
            } else if ($file['error'] !== UPLOAD_ERR_NO_FILE) {
                $error_msg = 'Terjadi kesalahan saat mengunggah file foto (Kode error: ' . $file['error'] . ').';
            }
            return false;
        }

        // 1. Cek ukuran file fisik (Maksimal 5 MB)
        $max_size = 5 * 1024 * 1024; // 5 MB
        if ($file['size'] > $max_size) {
            $error_msg = 'Ukuran file foto melebihi batas maksimal 5 MB.';
            return false;
        }

        // 2. Cek ekstensi file
        $ext = strtolower(pathinfo($file['name'], PATHINFO_EXTENSION));
        $allowed_exts = ['jpg', 'jpeg', 'png', 'webp'];
        if (!in_array($ext, $allowed_exts)) {
            $error_msg = 'Ekstensi file tidak didukung! Hanya diperbolehkan file gambar JPG, JPEG, PNG, dan WEBP.';
            return false;
        }

        // 3. Validasi tipe MIME konten sebenarnya menggunakan finfo & getimagesize
        $finfo = finfo_open(FILEINFO_MIME_TYPE);
        $real_mime = finfo_file($finfo, $file['tmp_name']);
        finfo_close($finfo);

        $allowed_mimes = [
            'image/jpeg',
            'image/pjpeg',
            'image/png',
            'image/x-png',
            'image/webp'
        ];

        if (!in_array($real_mime, $allowed_mimes)) {
            $error_msg = 'File yang diunggah bukan format gambar valid (' . htmlspecialchars($real_mime) . ').';
            return false;
        }

        // Pastikan bukan file script yang menyamar
        $img_info = @getimagesize($file['tmp_name']);
        if ($img_info === false) {
            $error_msg = 'File rusak atau tidak dapat diverifikasi sebagai gambar valid.';
            return false;
        }

        // 4. Pastikan folder penyimpanan uploads/produk/ tersedia
        $upload_dir = dirname(__DIR__) . DIRECTORY_SEPARATOR . 'uploads' . DIRECTORY_SEPARATOR . 'produk' . DIRECTORY_SEPARATOR;
        if (!is_dir($upload_dir)) {
            if (!@mkdir($upload_dir, 0755, true)) {
                $error_msg = 'Folder penyimpanan uploads/produk/ tidak dapat dibuat di server.';
                return false;
            }
        }

        // 5. Buat nama file unik dan aman
        $clean_ext = ($ext === 'jpeg') ? 'jpg' : $ext;
        $new_filename = 'snack_' . date('Ymd_His') . '_' . bin2hex(random_bytes(4)) . '.' . $clean_ext;
        $destination = $upload_dir . $new_filename;

        $success = false;
        if (is_uploaded_file($file['tmp_name'])) {
            $success = move_uploaded_file($file['tmp_name'], $destination);
        } else {
            $success = @copy($file['tmp_name'], $destination);
        }

        if (!$success) {
            $error_msg = 'Gagal memindahkan file foto ke folder uploads/produk/.';
            return false;
        }

        return $new_filename;
    }
}
