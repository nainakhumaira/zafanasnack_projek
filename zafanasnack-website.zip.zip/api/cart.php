<?php
/**
 * API Keranjang Belanja AJAX
 * ZAFANA SNACK
 */
header('Content-Type: application/json');
require_once __DIR__ . '/../config/koneksi.php';

if (!isset($_SESSION['cart'])) {
    $_SESSION['cart'] = [];
}

$action = $_GET['action'] ?? $_POST['action'] ?? 'get';
$response = ['success' => false, 'message' => 'Aksi tidak valid'];

switch ($action) {
    case 'get':
        $items = [];
        $total_items = 0;
        $total_price = 0;

        foreach ($_SESSION['cart'] as $id => $item) {
            $subtotal = $item['harga'] * $item['qty'];
            $total_items += $item['qty'];
            $total_price += $subtotal;
            $items[] = [
                'id_produk' => $item['id_produk'],
                'nama_produk' => $item['nama_produk'],
                'harga' => $item['harga'],
                'harga_formatted' => rupiah($item['harga']),
                'subtotal_formatted' => rupiah($subtotal),
                'qty' => $item['qty'],
                'stok' => $item['stok'],
                'berat_gram' => $item['berat_gram'],
                'foto' => $item['foto'],
                'foto_url' => get_product_image_url($item['foto'] ?? '')
            ];
        }

        $response = [
            'success' => true,
            'items' => $items,
            'total_items' => $total_items,
            'total_price' => $total_price,
            'total_price_formatted' => rupiah($total_price)
        ];
        break;

    case 'add':
        $id_produk = (int)($_POST['id_produk'] ?? 0);
        $qty = max(1, (int)($_POST['jumlah'] ?? 1));

        $stmt = mysqli_prepare($koneksi, "SELECT id_produk, nama_produk, harga, stok, foto, berat_gram FROM produk WHERE id_produk = ? AND status = 'aktif'");
        mysqli_stmt_bind_param($stmt, "i", $id_produk);
        mysqli_stmt_execute($stmt);
        $p = mysqli_fetch_assoc(mysqli_stmt_get_result($stmt));

        if (!$p) {
            $response = ['success' => false, 'message' => 'Produk tidak ditemukan atau nonaktif.'];
            break;
        }

        if ($p['stok'] <= 0) {
            $response = ['success' => false, 'message' => 'Maaf, stok produk ini sedang habis.'];
            break;
        }

        if (isset($_SESSION['cart'][$id_produk])) {
            $new_qty = $_SESSION['cart'][$id_produk]['qty'] + $qty;
            if ($new_qty > $p['stok']) {
                $new_qty = $p['stok'];
                $msg = 'Jumlah produk disesuaikan dengan sisa stok maksimal (' . $p['stok'] . ' bungkus).';
            } else {
                $msg = 'Jumlah ' . $p['nama_produk'] . ' diperbarui di keranjang!';
            }
            $_SESSION['cart'][$id_produk]['qty'] = $new_qty;
        } else {
            $current_qty = min($qty, $p['stok']);
            $_SESSION['cart'][$id_produk] = [
                'id_produk' => $p['id_produk'],
                'nama_produk' => $p['nama_produk'],
                'harga' => $p['harga'],
                'berat_gram' => $p['berat_gram'],
                'foto' => $p['foto'],
                'qty' => $current_qty,
                'stok' => $p['stok']
            ];
            $msg = $p['nama_produk'] . ' berhasil ditambahkan ke keranjang!';
        }

        $response = [
            'success' => true,
            'message' => $msg,
            'total_items' => total_cart_items(),
            'item_added' => $p['nama_produk']
        ];
        break;

    case 'update':
        $id_produk = (int)($_POST['id_produk'] ?? 0);
        $qty = (int)($_POST['qty'] ?? 1);

        if (isset($_SESSION['cart'][$id_produk])) {
            if ($qty <= 0) {
                unset($_SESSION['cart'][$id_produk]);
                $msg = 'Produk telah dihapus dari keranjang.';
            } else {
                $max = $_SESSION['cart'][$id_produk]['stok'];
                $_SESSION['cart'][$id_produk]['qty'] = min($qty, $max);
                $msg = 'Kuantitas diperbarui.';
            }
            $response = [
                'success' => true,
                'message' => $msg,
                'total_items' => total_cart_items()
            ];
        } else {
            $response = ['success' => false, 'message' => 'Item tidak ada dalam keranjang.'];
        }
        break;

    case 'remove':
        $id_produk = (int)($_POST['id_produk'] ?? $_GET['id_produk'] ?? 0);
        if (isset($_SESSION['cart'][$id_produk])) {
            $nama = $_SESSION['cart'][$id_produk]['nama_produk'];
            unset($_SESSION['cart'][$id_produk]);
            $response = [
                'success' => true,
                'message' => $nama . ' telah dihapus dari keranjang.',
                'total_items' => total_cart_items()
            ];
        } else {
            $response = ['success' => false, 'message' => 'Item tidak ditemukan.'];
        }
        break;

    case 'clear':
        $_SESSION['cart'] = [];
        $response = [
            'success' => true,
            'message' => 'Keranjang belanja dikosongkan.',
            'total_items' => 0
        ];
        break;
}

echo json_encode($response);
exit;
