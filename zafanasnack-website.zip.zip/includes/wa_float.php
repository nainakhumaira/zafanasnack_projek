<?php
$pesan_wa_default = urlencode("Halo Admin Zafana Snack, saya ingin bertanya seputar produk camilan yang tersedia.");
?>
<a href="https://wa.me/<?= WA_STORE_NUMBER ?>?text=<?= $pesan_wa_default ?>" class="wa-float" target="_blank" rel="noopener noreferrer" title="Chat WhatsApp Kami">
  <i class="fa-brands fa-whatsapp"></i>
  <span class="wa-float-tooltip">Tanya via WhatsApp</span>
</a>
