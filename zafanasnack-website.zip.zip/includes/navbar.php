<?php
$current_page = basename($_SERVER['PHP_SELF']);
$cart_count = total_cart_items();
$user_logged = current_user();
?>
<header class="navbar-wrapper">
  <!-- Minimalist Top Bar -->
  <div class="top-bar">
    <div class="container top-bar-content">
      <div class="top-bar-left">
        <span class="top-tagline">
          <i class="fa-solid fa-cookie-bite text-blue"></i>
          <strong><?= STORE_NAME ?>:</strong> <?= STORE_SLOGAN ?>
        </span>
      </div>
      <div class="top-bar-right">
        <a href="<?= get_whatsapp_url('Halo Admin Zafana Snack, saya ingin bertanya.') ?>" target="_blank" class="top-bar-link">
          <i class="fa-brands fa-whatsapp text-success"></i> WhatsApp: <?= STORE_PHONE ?>
        </a>
        <span class="top-divider">|</span>
        <span class="top-info-badge"><i class="fa-solid fa-shield-halved text-blue"></i> 100% Halal & Renyah</span>
      </div>
    </div>
  </div>

  <!-- Main Navbar (Background Putih, Aksen Biru #2563EB) -->
  <nav class="navbar" id="mainNavbar">
    <div class="container navbar-inner">
      
      <!-- 1. KIRI: Logo Brand -->
      <a href="<?= BASE_URL ?>" class="brand" aria-label="ZAFANA SNACK Beranda">
        <div class="brand-icon">
          <i class="fa-solid fa-cookie-bite"></i>
        </div>
        <div class="brand-text">
          <span class="brand-name">ZAFANA <span class="brand-badge">SNACK</span></span>
          <span class="brand-tagline">Teman Ngemil, Teman Bahagia!</span>
        </div>
      </a>

      <!-- 2. TENGAH: Menu Navigasi Utama -->
      <div class="nav-menu" id="navMenu">
        <a href="<?= BASE_URL ?>" class="nav-link <?= ($current_page == 'index.php') ? 'active' : '' ?>">
          <i class="fa-solid fa-house nav-icon-mobile"></i> Beranda
        </a>
        <a href="<?= BASE_URL ?>katalog.php" class="nav-link <?= ($current_page == 'katalog.php' || $current_page == 'detail_produk.php') ? 'active' : '' ?>">
          <i class="fa-solid fa-box-open nav-icon-mobile"></i> Produk
        </a>
        <a href="<?= BASE_URL ?>tentang.php" class="nav-link <?= ($current_page == 'tentang.php') ? 'active' : '' ?>">
          <i class="fa-solid fa-circle-info nav-icon-mobile"></i> Tentang Kami
        </a>
        <a href="<?= BASE_URL ?>kontak.php" class="nav-link <?= ($current_page == 'kontak.php') ? 'active' : '' ?>">
          <i class="fa-solid fa-envelope nav-icon-mobile"></i> Kontak
        </a>

        <!-- Mobile Quick User Section -->
        <div class="mobile-only-links">
          <?php if (is_logged_in()): ?>
            <div class="mobile-user-greeting">
              <i class="fa-regular fa-user text-blue"></i> Halo, <?= htmlspecialchars(explode(' ', $user_logged['nama_lengkap'])[0]) ?>
            </div>
            <?php if (is_admin()): ?>
              <a href="<?= BASE_URL ?>admin/" class="nav-link text-blue">
                <i class="fa-solid fa-gauge-high"></i> Dashboard Admin
              </a>
            <?php endif; ?>
            <a href="<?= BASE_URL ?>profil.php" class="nav-link">
              <i class="fa-regular fa-circle-user"></i> Profil Saya
            </a>
            <a href="<?= BASE_URL ?>riwayat_pesanan.php" class="nav-link">
              <i class="fa-solid fa-receipt"></i> Riwayat Pesanan
            </a>
            <a href="<?= BASE_URL ?>logout.php" class="nav-link text-danger">
              <i class="fa-solid fa-right-from-bracket"></i> Keluar
            </a>
          <?php else: ?>
            <div style="display: flex; gap: 8px; margin-top: 15px;">
              <a href="<?= BASE_URL ?>login.php" class="btn btn-sm btn-outline btn-block">Masuk</a>
              <a href="<?= BASE_URL ?>register.php" class="btn btn-sm btn-primary btn-block">Daftar</a>
            </div>
          <?php endif; ?>
        </div>
      </div>

      <!-- 3. KANAN: Ikon Akun, Keranjang, dan Tombol Login -->
      <div class="nav-actions">
        <!-- Tombol Keranjang Belanja (Slide-out Drawer Trigger) -->
        <button type="button" class="action-btn cart-btn-trigger" id="openCartDrawerBtn" title="Buka Keranjang Belanja" aria-label="Buka Keranjang Belanja">
          <i class="fa-solid fa-cart-shopping"></i>
          <span class="cart-badge-count" id="navCartCount"><?= $cart_count ?></span>
        </button>

        <!-- Akun Pengguna / Tombol Masuk (Desktop) -->
        <?php if (is_logged_in()): ?>
          <div class="user-dropdown-wrapper" id="userDropdownWrapper">
            <button class="user-profile-btn" id="userMenuToggle" aria-label="Menu Akun" title="Menu Akun">
              <div class="user-avatar-mini">
                <i class="fa-regular fa-user"></i>
              </div>
              <span class="user-name-label"><?= htmlspecialchars(explode(' ', $user_logged['nama_lengkap'])[0]) ?></span>
              <i class="fa-solid fa-chevron-down caret-icon"></i>
            </button>

            <!-- Dropdown Ringkas & Elegan -->
            <div class="user-dropdown-menu" id="userDropdownMenu">
              <div class="user-dropdown-header">
                <strong><?= htmlspecialchars($user_logged['nama_lengkap']) ?></strong>
                <span class="user-role-badge <?= is_admin() ? 'badge-admin' : 'badge-member' ?>">
                  <?= is_admin() ? 'Administrator' : 'Pelanggan' ?>
                </span>
              </div>
              
              <?php if (is_admin()): ?>
                <a href="<?= BASE_URL ?>admin/" class="dropdown-item item-highlight">
                  <i class="fa-solid fa-gauge-high"></i> Dashboard Admin
                </a>
                <div class="dropdown-divider"></div>
              <?php endif; ?>

              <a href="<?= BASE_URL ?>profil.php" class="dropdown-item">
                <i class="fa-regular fa-circle-user"></i> Profil Saya
              </a>
              <a href="<?= BASE_URL ?>riwayat_pesanan.php" class="dropdown-item">
                <i class="fa-solid fa-receipt"></i> Riwayat Pesanan
              </a>
              <div class="dropdown-divider"></div>
              <a href="<?= BASE_URL ?>logout.php" class="dropdown-item text-danger">
                <i class="fa-solid fa-right-from-bracket"></i> Keluar
              </a>
            </div>
          </div>
        <?php else: ?>
          <div class="auth-buttons-desktop">
            <a href="<?= BASE_URL ?>login.php" class="btn btn-sm btn-outline">
              Masuk
            </a>
            <a href="<?= BASE_URL ?>register.php" class="btn btn-sm btn-primary">
              Daftar
            </a>
          </div>
        <?php endif; ?>

        <!-- Tombol Hamburger Mobile -->
        <button class="menu-toggle" id="menuToggle" aria-label="Buka Menu Navigasi">
          <i class="fa-solid fa-bars"></i>
        </button>
      </div>

    </div>
  </nav>
</header>
