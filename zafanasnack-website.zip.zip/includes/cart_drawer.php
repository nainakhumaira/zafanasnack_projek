<!-- DRAWER KERANJANG BELANJA (TERSEMBUNYI SECARA DEFAULT) -->
<div class="cart-backdrop" id="cartBackdrop" aria-hidden="true"></div>

<aside class="cart-drawer" id="cartDrawer" aria-label="Keranjang Belanja" aria-hidden="true">
  <!-- Header Drawer -->
  <div class="cart-drawer-header">
    <div style="display: flex; align-items: center; gap: 10px;">
      <div class="drawer-header-icon">
        <i class="fa-solid fa-bag-shopping"></i>
      </div>
      <div>
        <h3 style="font-size: 16px; font-weight: 800; color: var(--navy); margin: 0; line-height: 1.2;">Keranjang Saya</h3>
        <span class="drawer-count-label" id="drawerItemCount">0 camilan</span>
      </div>
    </div>
    <button type="button" class="btn-close-drawer" id="closeCartDrawer" aria-label="Tutup Keranjang" title="Tutup (Esc)">
      <i class="fa-solid fa-xmark"></i>
    </button>
  </div>

  <!-- Shipping / Promo Progress Box -->
  <div class="shipping-progress-box">
    <div class="shipping-progress-text" id="shippingProgressText">
      <i class="fa-solid fa-truck-fast text-blue"></i> Belanja hemat camilan favoritmu!
    </div>
    <div class="shipping-progress-bar">
      <div class="shipping-progress-fill" id="shippingProgressFill" style="width: 0%;"></div>
    </div>
  </div>

  <!-- Kontainer Produk dalam Keranjang (Diperbarui dinamis via AJAX di main.js) -->
  <div class="cart-drawer-body" id="cartDrawerItems">
    <!-- State Kosong Awal -->
    <div class="drawer-empty-state">
      <div class="drawer-empty-icon">
        <i class="fa-solid fa-cart-shopping"></i>
      </div>
      <h4>Keranjang Belanja Kosong</h4>
      <p>Belum ada camilan yang kamu pilih. Yuk, cari snack renyah favoritmu sekarang!</p>
      <a href="<?= BASE_URL ?>katalog.php" class="btn btn-sm btn-primary" style="margin-top: 15px;" id="emptyStateCatalogBtn">
        <i class="fa-solid fa-cookie-bite"></i> Jelajahi Katalog Snack
      </a>
    </div>
  </div>

  <!-- Footer Drawer dengan Rincian Total & Checkout -->
  <div class="cart-drawer-footer" id="cartDrawerFooter" style="display: none;">
    <div class="cart-summary-row">
      <span class="text-muted">Total Belanja:</span>
      <span class="cart-total-price" id="drawerTotalPrice">Rp 0</span>
    </div>
    <div style="font-size: 11px; color: var(--navy-light); margin-bottom: 14px;">
      *Ongkir flat dihitung otomatis saat checkout pesanan.
    </div>

    <div style="display: flex; flex-direction: column; gap: 8px;">
      <a href="<?= BASE_URL ?>checkout.php" class="btn btn-primary btn-block btn-lg" style="box-shadow: 0 4px 15px rgba(37,99,235,0.35);">
        <i class="fa-solid fa-credit-card"></i> Lanjut ke Checkout
      </a>
      <a href="<?= BASE_URL ?>keranjang.php" class="btn btn-light btn-block btn-sm">
        Lihat Keranjang Versi Penuh
      </a>
    </div>
  </div>
</aside>

<!-- Floating Toast Notification Container -->
<div class="toast-container" id="toastContainer" aria-live="polite"></div>
