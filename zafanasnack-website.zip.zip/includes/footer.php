<footer class="footer scroll-animate animate-fade-in">
  <!-- USP Bar / Value Pre-footer -->
  <div class="footer-usp-bar">
    <div class="container">
      <div class="footer-usp-grid">
        <div class="footer-usp-item">
          <div class="footer-usp-icon"><i class="fa-solid fa-truck-fast"></i></div>
          <div>
            <strong>Pengiriman Cepat & Aman</strong>
            <p>Dikemas rapi dengan bubble wrap tebal</p>
          </div>
        </div>
        <div class="footer-usp-item">
          <div class="footer-usp-icon"><i class="fa-solid fa-award"></i></div>
          <div>
            <strong>100% Kualitas Terjamin</strong>
            <p>Bahan segar, renyah & higienis</p>
          </div>
        </div>
        <div class="footer-usp-item">
          <div class="footer-usp-icon"><i class="fa-solid fa-tags"></i></div>
          <div>
            <strong>Harga Ramah Kantong</strong>
            <p>Cocok untuk mahasiswa & keluarga</p>
          </div>
        </div>
        <div class="footer-usp-item">
          <div class="footer-usp-icon"><i class="fa-solid fa-headset"></i></div>
          <div>
            <strong>Respon Cepat WhatsApp</strong>
            <p>Siap melayani pertanyaan & pesanan</p>
          </div>
        </div>
      </div>
    </div>
  </div>

  <!-- Main Footer Content -->
  <div class="container footer-main">
    <div class="footer-grid">
      <!-- Kolom 1: Brand Info -->
      <div class="footer-col">
        <div class="footer-brand">
          <div class="brand-icon">
            <i class="fa-solid fa-cookie-bite"></i>
          </div>
          <div>
            <span class="footer-brand-title">ZAFANA <span>SNACK</span></span>
            <div style="font-size: 11px; color: #94A3B8; font-weight: 600;">Teman Ngemil, Teman Bahagia!</div>
          </div>
        </div>
        <p class="footer-desc">
          ZAFANA SNACK menghadirkan aneka camilan pilihan dengan cita rasa gurih, pedas nikmat, dan manis legit. Dibuat dengan resep istimewa untuk menemani setiap waktu santai, nugas, maupun kumpul ceria.
        </p>
        <div class="footer-socials">
          <a href="https://instagram.com" target="_blank" aria-label="Instagram"><i class="fa-brands fa-instagram"></i></a>
          <a href="https://tiktok.com" target="_blank" aria-label="TikTok"><i class="fa-brands fa-tiktok"></i></a>
          <a href="https://facebook.com" target="_blank" aria-label="Facebook"><i class="fa-brands fa-facebook-f"></i></a>
          <a href="<?= get_whatsapp_url('Halo Admin Zafana Snack, saya ingin bertanya.') ?>" target="_blank" aria-label="WhatsApp"><i class="fa-brands fa-whatsapp"></i></a>
        </div>
      </div>

      <!-- Kolom 2: Menu Utama -->
      <div class="footer-col">
        <h4 class="footer-title">Menu Utama</h4>
        <ul class="footer-links">
          <li><a href="<?= BASE_URL ?>"><i class="fa-solid fa-angle-right"></i> Beranda</a></li>
          <li><a href="<?= BASE_URL ?>katalog.php"><i class="fa-solid fa-angle-right"></i> Katalog Produk</a></li>
          <li><a href="<?= BASE_URL ?>katalog.php?filter=promo"><i class="fa-solid fa-angle-right"></i> Promo & Diskon</a></li>
          <li><a href="<?= BASE_URL ?>tentang.php"><i class="fa-solid fa-angle-right"></i> Tentang Kami</a></li>
          <li><a href="<?= BASE_URL ?>kontak.php"><i class="fa-solid fa-angle-right"></i> Hubungi Kami</a></li>
        </ul>
      </div>

      <!-- Kolom 3: Layanan Pelanggan -->
      <div class="footer-col">
        <h4 class="footer-title">Layanan Pembeli</h4>
        <ul class="footer-links">
          <li><a href="<?= BASE_URL ?>riwayat_pesanan.php"><i class="fa-solid fa-angle-right"></i> Lacak Status Pesanan</a></li>
          <li><a href="<?= BASE_URL ?>keranjang.php"><i class="fa-solid fa-angle-right"></i> Keranjang Belanja</a></li>
          <li><a href="<?= BASE_URL ?>login.php"><i class="fa-solid fa-angle-right"></i> Masuk / Daftar Akun</a></li>
          <li><a href="<?= get_whatsapp_url('Halo Admin Zafana Snack, saya ingin tanya cara pemesanan.') ?>" target="_blank"><i class="fa-solid fa-angle-right"></i> Panduan Pemesanan</a></li>
        </ul>
      </div>

      <!-- Kolom 4: Hubungi & Alamat -->
      <div class="footer-col">
        <h4 class="footer-title">Kontak & Workshop</h4>
        <ul class="footer-contact-list">
          <li>
            <i class="fa-solid fa-location-dot"></i>
            <span><?= STORE_ADDRESS ?></span>
          </li>
          <li>
            <i class="fa-solid fa-phone"></i>
            <span><?= STORE_PHONE ?></span>
          </li>
          <li>
            <i class="fa-solid fa-envelope"></i>
            <span>order@zafanasnack.com</span>
          </li>
          <li>
            <i class="fa-solid fa-clock"></i>
            <span>Senin - Sabtu: 08.00 - 21.00 WIB</span>
          </li>
        </ul>

        <div style="margin-top: 18px;">
          <div style="font-size: 12px; color: #94A3B8; margin-bottom: 8px; font-weight: 600;">Metode Pembayaran:</div>
          <div class="payment-badges">
            <span class="pay-badge">BCA</span>
            <span class="pay-badge">Mandiri</span>
            <span class="pay-badge">BNI</span>
            <span class="pay-badge">QRIS</span>
            <span class="pay-badge">GoPay</span>
            <span class="pay-badge">ShopeePay</span>
          </div>
        </div>
      </div>
    </div>

    <!-- Bottom Copyright -->
    <div class="footer-bottom">
      <div>
        &copy; <?= date('Y') ?> <strong>ZAFANA SNACK</strong>. Seluruh Hak Cipta Dilindungi. Proyek Usaha Nyata & Akademik.
      </div>
      <div class="footer-bottom-links">
        <span>"Teman Ngemil, Teman Bahagia!"</span>
      </div>
    </div>
  </div>
</footer>

<!-- 1. Drawer Slide-Out Keranjang Belanja Global (Hidden by Default) -->
<?php include_once __DIR__ . '/cart_drawer.php'; ?>

<!-- 2. Floating WhatsApp Button -->
<?php include_once __DIR__ . '/wa_float.php'; ?>

<!-- 3. Main Javascript (IntersectionObserver, AJAX Drawer Cart, Toast) -->
<script src="<?= BASE_URL ?>assets/js/main.js?v=<?= time() ?>"></script>
</body>
</html>
