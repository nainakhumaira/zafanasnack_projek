<?php
$admin_page_title = "Pengaturan Profil & Identitas Toko";
require_once __DIR__ . '/includes/header.php';
require_once __DIR__ . '/includes/sidebar.php';

$success = '';
$error = '';

// Proses Simpan Pengaturan
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $nama_toko = trim($_POST['nama_toko'] ?? '');
    $slogan = trim($_POST['slogan'] ?? '');
    $alamat = trim($_POST['alamat'] ?? '');
    $no_telepon = trim($_POST['no_telepon'] ?? '');
    $no_whatsapp = trim($_POST['no_whatsapp'] ?? '');
    $email_toko = trim($_POST['email_toko'] ?? '');
    $jam_operasional = trim($_POST['jam_operasional'] ?? '');

    if (empty($nama_toko) || empty($alamat) || empty($no_whatsapp)) {
        $error = 'Nama toko, alamat, dan nomor WhatsApp wajib diisi!';
    } else {
        // Bersihkan format nomor WhatsApp (hanya angka, pastikan diawali 62)
        $no_wa_clean = preg_replace('/[^\d]/', '', $no_whatsapp);
        if (str_starts_with($no_wa_clean, '0')) {
            $no_wa_clean = '62' . substr($no_wa_clean, 1);
        }

        $settings_to_update = [
            'nama_toko' => [$nama_toko, 'Nama resmi toko/brand'],
            'slogan' => [$slogan, 'Slogan toko'],
            'alamat' => [$alamat, 'Alamat lengkap toko / rumah produksi'],
            'no_telepon' => [$no_telepon, 'Nomor telepon toko berformat tampilan'],
            'no_whatsapp' => [$no_wa_clean, 'Nomor WhatsApp format internasional'],
            'email_toko' => [$email_toko, 'Alamat email resmi toko'],
            'jam_operasional' => [$jam_operasional, 'Jam operasional dan pengiriman pesanan']
        ];

        $stmt = mysqli_prepare($koneksi, "INSERT INTO pengaturan (kunci, nilai, keterangan) VALUES (?, ?, ?) ON DUPLICATE KEY UPDATE nilai = VALUES(nilai), keterangan = VALUES(keterangan)");
        
        $all_ok = true;
        foreach ($settings_to_update as $k => $v) {
            mysqli_stmt_bind_param($stmt, "sss", $k, $v[0], $v[1]);
            if (!mysqli_stmt_execute($stmt)) {
                $all_ok = false;
                break;
            }
        }

        if ($all_ok) {
            set_flash('success', 'Pengaturan toko berhasil diperbarui di database! Perubahan langsung diterapkan di Beranda, Kontak, Footer, dan WhatsApp.');
            header("Location: " . BASE_URL . "admin/pengaturan.php");
            exit;
        } else {
            $error = 'Gagal menyimpan pengaturan ke database: ' . mysqli_error($koneksi);
        }
    }
}

// Ambil data pengaturan saat ini dari database
$current_settings = [];
$res = mysqli_query($koneksi, "SELECT kunci, nilai FROM pengaturan");
if ($res) {
    while ($r = mysqli_fetch_assoc($res)) {
        $current_settings[$r['kunci']] = $r['nilai'];
    }
}

$val_nama = $current_settings['nama_toko'] ?? STORE_NAME;
$val_slogan = $current_settings['slogan'] ?? STORE_SLOGAN;
$val_alamat = $current_settings['alamat'] ?? STORE_ADDRESS;
$val_telp = $current_settings['no_telepon'] ?? STORE_PHONE;
$val_wa = $current_settings['no_whatsapp'] ?? WA_STORE_NUMBER;
$val_email = $current_settings['email_toko'] ?? STORE_EMAIL;
$val_jam = $current_settings['jam_operasional'] ?? STORE_HOURS;
?>

<main class="admin-main">
  <div class="admin-topbar">
    <div>
      <h2 style="font-size: 20px; font-weight: 800; color: var(--navy);">Pengaturan Informasi Toko</h2>
      <p style="font-size: 13px; color: var(--navy-light);">Kelola identitas resmi ZAFANA SNACK, kontak WhatsApp, dan alamat operasional</p>
    </div>
    <a href="<?= BASE_URL ?>" target="_blank" class="btn btn-sm btn-outline">
      <i class="fa-solid fa-arrow-up-right-from-square"></i> Cek Tampilan Website
    </a>
  </div>

  <div class="admin-body">
    <?= get_flash() ?>

    <?php if (!empty($error)): ?>
      <div class="alert alert-danger"><?= htmlspecialchars($error) ?></div>
    <?php endif; ?>

    <div style="display: grid; grid-template-columns: 2fr 1fr; gap: 25px; align-items: start;">
      
      <!-- Formulir Pengaturan -->
      <div class="card">
        <form action="<?= BASE_URL ?>admin/pengaturan.php" method="POST">
          <h3 style="font-size: 16px; color: var(--navy); margin-bottom: 15px; padding-bottom: 10px; border-bottom: 1px solid var(--border-color);">
            <i class="fa-solid fa-store text-blue"></i> Identitas & Branding
          </h3>

          <div class="form-group">
            <label class="form-label">Nama Toko *</label>
            <input type="text" name="nama_toko" class="form-control" value="<?= htmlspecialchars($val_nama) ?>" required>
            <small style="color: var(--navy-light); font-size: 11px;">Nama ini tampil di Header, Logo, Title bar, dan Footer.</small>
          </div>

          <div class="form-group">
            <label class="form-label">Slogan Toko</label>
            <input type="text" name="slogan" class="form-control" value="<?= htmlspecialchars($val_slogan) ?>">
            <small style="color: var(--navy-light); font-size: 11px;">Contoh: Teman Ngemil, Teman Bahagia!</small>
          </div>

          <h3 style="font-size: 16px; color: var(--navy); margin: 25px 0 15px; padding-bottom: 10px; border-bottom: 1px solid var(--border-color);">
            <i class="fa-solid fa-address-book text-blue"></i> Kontak Resmi & Layanan Pelanggan
          </h3>

          <div style="display: grid; grid-template-columns: 1fr 1fr; gap: 20px;">
            <div class="form-group">
              <label class="form-label">Nomor WhatsApp Toko *</label>
              <input type="text" name="no_whatsapp" class="form-control" placeholder="Contoh: 6289624614578" value="<?= htmlspecialchars($val_wa) ?>" required>
              <small style="color: var(--navy-light); font-size: 11px;">Format internasional Indonesia: awali <strong>62</strong> tanpa simbol + atau spasi.</small>
            </div>

            <div class="form-group">
              <label class="form-label">Nomor Telepon Tampilan</label>
              <input type="text" name="no_telepon" class="form-control" placeholder="Contoh: +62 896-2461-4578" value="<?= htmlspecialchars($val_telp) ?>">
              <small style="color: var(--navy-light); font-size: 11px;">Format rapi yang dibaca pengunjung website.</small>
            </div>
          </div>

          <div style="display: grid; grid-template-columns: 1fr 1fr; gap: 20px;">
            <div class="form-group">
              <label class="form-label">Email Resmi Toko</label>
              <input type="email" name="email_toko" class="form-control" value="<?= htmlspecialchars($val_email) ?>">
            </div>

            <div class="form-group">
              <label class="form-label">Jam Operasional / Produksi</label>
              <input type="text" name="jam_operasional" class="form-control" value="<?= htmlspecialchars($val_jam) ?>">
            </div>
          </div>

          <div class="form-group">
            <label class="form-label">Alamat Lengkap Toko / Dapur Produksi *</label>
            <textarea name="alamat" class="form-control" rows="3" required><?= htmlspecialchars($val_alamat) ?></textarea>
            <small style="color: var(--navy-light); font-size: 11px;">Alamat lengkap yang dicantumkan pada bagian kontak, tentang kami, dan footer.</small>
          </div>

          <div style="margin-top: 25px; padding-top: 15px; border-top: 1px solid var(--border-color); display: flex; justify-content: flex-end; gap: 10px;">
            <button type="submit" class="btn btn-primary btn-lg" style="padding: 10px 24px;">
              <i class="fa-solid fa-floppy-disk"></i> Simpan Perubahan Pengaturan
            </button>
          </div>
        </form>
      </div>

      <!-- Preview & Informasi Sinkronisasi -->
      <div>
        <div class="card" style="margin-bottom: 20px; background: #F8FAFC; border: 1px solid #E2E8F0;">
          <h4 style="font-size: 14px; font-weight: 700; color: var(--navy); margin-bottom: 12px;">
            <i class="fa-solid fa-circle-check text-success"></i> Terhubung Langsung ke MySQL
          </h4>
          <p style="font-size: 12px; color: var(--navy-light); line-height: 1.6; margin-bottom: 12px;">
            Seluruh data identitas toko di atas disimpan di tabel <code>pengaturan</code> MySQL di hosting Anda.
          </p>
          <ul style="font-size: 12px; color: var(--navy); padding-left: 18px; line-height: 1.6;">
            <li>Perubahan langsung aktif tanpa perlu mengubah script kode.</li>
            <li>Tombol WhatsApp seluruh website otomatis mengarah ke nomor baru.</li>
            <li>Alamat dan jam operasional langsung terbarui di seluruh halaman.</li>
          </ul>
        </div>

        <div class="card" style="background: #EFF6FF; border: 1px solid #BFDBFE;">
          <h4 style="font-size: 14px; font-weight: 700; color: #1E40AF; margin-bottom: 8px;">
            <i class="fa-brands fa-whatsapp text-success"></i> Tes Tautan WhatsApp
          </h4>
          <p style="font-size: 12px; color: #1E3A8A; margin-bottom: 12px;">
            Klik tombol berikut untuk memverifikasi nomor WhatsApp yang tersimpan saat ini:
          </p>
          <a href="<?= get_whatsapp_url('Halo Admin ZAFANA SNACK, tes konfirmasi WhatsApp dari dashboard pengaturan.') ?>" target="_blank" class="btn btn-sm btn-block" style="background: #22C55E; color: #fff; font-weight: 700; text-align: center; justify-content: center;">
            <i class="fa-brands fa-whatsapp"></i> Tes Buka Chat WhatsApp
          </a>
        </div>
      </div>

    </div>
  </div>
</main>

<?php require_once __DIR__ . '/includes/footer.php'; ?>
