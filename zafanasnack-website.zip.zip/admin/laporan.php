<?php
$admin_page_title = "Laporan Penjualan";
require_once __DIR__ . '/includes/header.php';
require_once __DIR__ . '/includes/sidebar.php';

// Default tanggal: awal bulan sampai hari ini
$tgl_mulai = $_GET['tgl_mulai'] ?? date('Y-m-01');
$tgl_selesai = $_GET['tgl_selesai'] ?? date('Y-m-d');

// Filter status pesanan yang dihitung omsetnya (diproses, dikirim, selesai)
$sql = "SELECT p.*, u.nama_lengkap 
        FROM pesanan p 
        JOIN users u ON p.id_user = u.id_user 
        WHERE DATE(p.tanggal_pesanan) BETWEEN ? AND ? 
        AND p.status_pesanan IN ('diproses', 'dikirim', 'selesai')
        ORDER BY p.tanggal_pesanan DESC";

$stmt = mysqli_prepare($koneksi, $sql);
mysqli_stmt_bind_param($stmt, "ss", $tgl_mulai, $tgl_selesai);
mysqli_stmt_execute($stmt);
$result = mysqli_stmt_get_result($stmt);

// Hitung total ringkasan
$total_omset = 0;
$total_transaksi = 0;
$data_laporan = [];

while ($row = mysqli_fetch_assoc($result)) {
    $total_omset += $row['total_bayar'];
    $total_transaksi++;
    $data_laporan[] = $row;
}

$rata_rata = $total_transaksi > 0 ? ($total_omset / $total_transaksi) : 0;
?>

<main class="admin-main">
  <div class="admin-topbar">
    <div>
      <h2 style="font-size: 20px; font-weight: 800; color: var(--navy);">Laporan Penjualan</h2>
      <p style="font-size: 13px; color: var(--navy-light);">Rekap pendapatan dan transaksi ZAFANA SNACK untuk pembukuan & laporan tugas kuliah</p>
    </div>
    <button onclick="window.print()" class="btn btn-primary btn-sm btn-no-print">
      <i class="fa-solid fa-print"></i> Cetak / Simpan PDF
    </button>
  </div>

  <div class="admin-body">
    <!-- Form Filter Periode -->
    <div class="card btn-no-print" style="margin-bottom: 20px;">
      <form action="<?= BASE_URL ?>admin/laporan.php" method="GET" style="display: flex; gap: 15px; align-items: flex-end; flex-wrap: wrap;">
        <div style="flex: 1; min-width: 160px;">
          <label class="form-label">Tanggal Mulai:</label>
          <input type="date" name="tgl_mulai" class="form-control" value="<?= htmlspecialchars($tgl_mulai) ?>" required>
        </div>
        <div style="flex: 1; min-width: 160px;">
          <label class="form-label">Tanggal Selesai:</label>
          <input type="date" name="tgl_selesai" class="form-control" value="<?= htmlspecialchars($tgl_selesai) ?>" required>
        </div>
        <button type="submit" class="btn btn-primary" style="height: 42px;">
          <i class="fa-solid fa-filter"></i> Tampilkan Laporan
        </button>
        <a href="<?= BASE_URL ?>admin/laporan.php" class="btn btn-light" style="height: 42px;">Reset</a>
      </form>
    </div>

    <!-- Ringkasan Metrik Laporan -->
    <div class="stat-grid" style="margin-bottom: 20px;">
      <div class="stat-card">
        <div class="stat-icon green">
          <i class="fa-solid fa-money-bill-trend-up"></i>
        </div>
        <div class="stat-info">
          <h3><?= rupiah($total_omset) ?></h3>
          <p>Total Pendapatan Bersih</p>
        </div>
      </div>

      <div class="stat-card">
        <div class="stat-icon blue">
          <i class="fa-solid fa-receipt"></i>
        </div>
        <div class="stat-info">
          <h3><?= $total_transaksi ?> Pesanan</h3>
          <p>Jumlah Transaksi Sukses</p>
        </div>
      </div>

      <div class="stat-card">
        <div class="stat-icon orange">
          <i class="fa-solid fa-chart-line"></i>
        </div>
        <div class="stat-info">
          <h3><?= rupiah($rata_rata) ?></h3>
          <p>Rata-rata Nilai Pesanan</p>
        </div>
      </div>
    </div>

    <!-- Kop Cetak untuk Laporan Resmi Kuliah / Bisnis -->
    <div style="display: none; text-align: center; margin-bottom: 25px;" class="print-header">
      <h2 style="font-size: 22px; font-weight: 800; color: #1E293B;">LAPORAN PENJUALAN ZAFANA SNACK</h2>
      <p style="font-size: 13px; color: #64748B;">Periode: <?= date('d M Y', strtotime($tgl_mulai)) ?> s/d <?= date('d M Y', strtotime($tgl_selesai)) ?></p>
      <hr style="margin-top: 10px; border: 1px solid #CBD5E1;">
    </div>

    <style>
      @media print {
        .print-header { display: block !important; }
      }
    </style>

    <!-- Tabel Data Laporan -->
    <div class="card" style="padding: 0; overflow: hidden;">
      <div class="table-responsive">
        <table class="table">
          <thead>
            <tr>
              <th style="width: 50px;">No</th>
              <th>Kode Pesanan</th>
              <th>Waktu Transaksi</th>
              <th>Pelanggan</th>
              <th>Metode Pembayaran</th>
              <th>Status</th>
              <th style="text-align: right;">Total Nilai</th>
            </tr>
          </thead>
          <tbody>
            <?php if (!empty($data_laporan)): $no = 1; ?>
              <?php foreach ($data_laporan as $row): ?>
                <tr>
                  <td><?= $no++ ?></td>
                  <td><strong><?= htmlspecialchars($row['kode_pesanan']) ?></strong></td>
                  <td style="font-size: 13px;"><?= date('d/m/Y H:i', strtotime($row['tanggal_pesanan'])) ?></td>
                  <td><?= htmlspecialchars($row['nama_penerima']) ?></td>
                  <td><?= htmlspecialchars($row['metode_pembayaran']) ?></td>
                  <td>
                    <span style="font-size: 11px; font-weight: 700; padding: 2px 8px; border-radius: 10px; background: #DCFCE7; color: #16A34A;">
                      <?= strtoupper($row['status_pesanan']) ?>
                    </span>
                  </td>
                  <td style="text-align: right; font-weight: 800; color: var(--primary-blue);">
                    <?= rupiah($row['total_bayar']) ?>
                  </td>
                </tr>
              <?php endforeach; ?>
            <?php else: ?>
              <tr>
                <td colspan="7" style="text-align: center; padding: 40px; color: var(--navy-light);">
                  Tidak ada transaksi penjualan pada rentang tanggal <?= date('d/m/Y', strtotime($tgl_mulai)) ?> sampai <?= date('d/m/Y', strtotime($tgl_selesai)) ?>.
                </td>
              </tr>
            <?php endif; ?>
          </tbody>
          <?php if (!empty($data_laporan)): ?>
            <tfoot>
              <tr style="background: var(--bg-soft); font-size: 15px;">
                <td colspan="6" style="text-align: right; font-weight: 800; color: var(--navy);">TOTAL PENJUALAN KESELURUHAN:</td>
                <td style="text-align: right; font-weight: 800; color: var(--primary-blue); font-size: 16px;"><?= rupiah($total_omset) ?></td>
              </tr>
            </tfoot>
          <?php endif; ?>
        </table>
      </div>
    </div>

<?php require_once __DIR__ . '/includes/footer.php'; ?>
