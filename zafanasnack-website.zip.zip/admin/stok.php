<?php
$admin_page_title = "Pantau & Kelola Stok";
require_once __DIR__ . '/includes/header.php';
require_once __DIR__ . '/includes/sidebar.php';

// UPDATE CEPAT SATU PRODUK
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['action']) && $_POST['action'] === 'update_single') {
    $id_produk = (int)($_POST['id_produk'] ?? 0);
    $stok_baru = max(0, (int)($_POST['stok'] ?? 0));

    $stmt = mysqli_prepare($koneksi, "UPDATE produk SET stok = ? WHERE id_produk = ?");
    mysqli_stmt_bind_param($stmt, "ii", $stok_baru, $id_produk);
    mysqli_stmt_execute($stmt);

    set_flash('success', 'Stok produk berhasil diperbarui!');
    header("Location: " . BASE_URL . "admin/stok.php");
    exit;
}

// QUERY PRODUK
$result = mysqli_query($koneksi, "SELECT p.*, k.nama_kategori 
                                  FROM produk p 
                                  JOIN kategori k ON p.id_kategori = k.id_kategori 
                                  ORDER BY p.stok ASC");
?>

<main class="admin-main">
  <div class="admin-topbar">
    <div>
      <h2 style="font-size: 20px; font-weight: 800; color: var(--navy);">Pantau & Update Cepat Stok</h2>
      <p style="font-size: 13px; color: var(--navy-light);">Kelola ketersediaan stok snack toko secara langsung</p>
    </div>
  </div>

  <div class="admin-body">
    <?= get_flash() ?>

    <div class="card" style="padding: 0; overflow: hidden;">
      <div class="card-header" style="padding: 16px 20px; margin-bottom: 0;">
        <h3>Daftar Ketersediaan Stok Camilan</h3>
      </div>

      <div class="table-responsive">
        <table class="table">
          <thead>
            <tr>
              <th style="width: 60px;">Foto</th>
              <th>Nama Camilan</th>
              <th>Kategori</th>
              <th>Harga</th>
              <th>Status Stok</th>
              <th style="width: 200px;">Ubah Stok Cepat</th>
            </tr>
          </thead>
          <tbody>
            <?php while ($p = mysqli_fetch_assoc($result)): ?>
              <tr>
                <td>
                  <img src="<?= get_product_image_url($p['foto'] ?? '') ?>" 
                       style="width: 48px; height: 48px; object-fit: cover; border-radius: 8px; border: 1px solid var(--border-color); background: var(--bg-soft);"
                       loading="lazy"
                       onerror="this.onerror=null; this.src='<?= BASE_URL ?>assets/images/products/default_snack.jpg';">
                </td>
                <td>
                  <strong style="color: var(--navy);"><?= htmlspecialchars($p['nama_produk']) ?></strong>
                </td>
                <td>
                  <span style="font-size: 12px; color: var(--navy-light);"><?= htmlspecialchars($p['nama_kategori']) ?></span>
                </td>
                <td style="font-weight: 600;"><?= rupiah($p['harga']) ?></td>
                <td>
                  <?php if ($p['stok'] <= 0): ?>
                    <span style="background: #FEE2E2; color: #DC2626; font-weight: 800; font-size: 11px; padding: 3px 8px; border-radius: 12px;">Habis (0)</span>
                  <?php elseif ($p['stok'] < 10): ?>
                    <span style="background: #FEF3C7; color: #D97706; font-weight: 800; font-size: 11px; padding: 3px 8px; border-radius: 12px;">Menipis (<?= $p['stok'] ?>)</span>
                  <?php else: ?>
                    <span style="background: #DCFCE7; color: #16A34A; font-weight: 800; font-size: 11px; padding: 3px 8px; border-radius: 12px;">Aman (<?= $p['stok'] ?>)</span>
                  <?php endif; ?>
                </td>
                <td>
                  <form action="<?= BASE_URL ?>admin/stok.php" method="POST" style="display: flex; gap: 8px; align-items: center;">
                    <input type="hidden" name="action" value="update_single">
                    <input type="hidden" name="id_produk" value="<?= $p['id_produk'] ?>">
                    <input type="number" name="stok" value="<?= (int)$p['stok'] ?>" min="0" 
                           style="width: 80px; padding: 6px 10px; border: 1px solid var(--border-color); border-radius: 6px; font-weight: 700;">
                    <button type="submit" class="btn btn-sm btn-primary">
                      <i class="fa-solid fa-floppy-disk"></i> Simpan
                    </button>
                  </form>
                </td>
              </tr>
            <?php endwhile; ?>
          </tbody>
        </table>
      </div>
    </div>

<?php require_once __DIR__ . '/includes/footer.php'; ?>
