<?php
/**
 * Sistem Backup Database ZAFANA SNACK
 * Menghasilkan file SQL murni tanpa markup HTML untuk impor phpMyAdmin
 */

require_once __DIR__ . '/../config/koneksi.php';

// Pastikan hanya role admin yang bisa mengakses
if (!is_admin()) {
    header("Location: " . BASE_URL . "admin/login.php");
    exit;
}

$backup_dir = dirname(__DIR__) . DIRECTORY_SEPARATOR . 'backups' . DIRECTORY_SEPARATOR;
if (!is_dir($backup_dir)) {
    @mkdir($backup_dir, 0755, true);
}
// Buat proteksi direktori .htaccess agar file backup tidak dapat diunduh langsung via URL publik
if (!file_exists($backup_dir . '.htaccess')) {
    @file_put_contents($backup_dir . '.htaccess', "Order Deny,Allow\nDeny from all\n");
}

/**
 * Generator Dump SQL Standar Kompatibel phpMyAdmin & MySQL/MariaDB
 */
function generate_sql_dump($koneksi) {
    global $db_name;
    $active_db = !empty($db_name) ? $db_name : 'db_zafanasnack';

    $tables = [];
    $result = mysqli_query($koneksi, "SHOW TABLES");
    if ($result) {
        while ($row = mysqli_fetch_row($result)) {
            $tables[] = $row[0];
        }
    }

    $sql  = "-- ========================================================\n";
    $sql .= "-- CADANGAN DATABASE RESMI " . (defined('STORE_NAME') ? STORE_NAME : 'ZAFANA SNACK') . "\n";
    $sql .= "-- Database       : " . $active_db . "\n";
    $sql .= "-- Waktu Backup   : " . date('Y-m-d H:i:s') . " WIB\n";
    $sql .= "-- Total Tabel    : " . count($tables) . " tabel (" . implode(', ', $tables) . ")\n";
    $sql .= "-- Generator      : ZAFANA SNACK Automated SQL Backup Engine\n";
    $sql .= "-- PHP Version    : " . PHP_VERSION . "\n";
    $sql .= "-- ========================================================\n\n";

    $sql .= "SET NAMES utf8mb4;\n";
    $sql .= "SET FOREIGN_KEY_CHECKS = 0;\n";
    $sql .= "SET SQL_MODE = \"NO_AUTO_VALUE_ON_ZERO\";\n";
    $sql .= "SET AUTOCOMMIT = 0;\n";
    $sql .= "START TRANSACTION;\n";
    $sql .= "SET time_zone = \"+00:00\";\n\n";

    foreach ($tables as $table) {
        $sql .= "-- --------------------------------------------------------\n";
        $sql .= "-- Struktur Tabel `{$table}`\n";
        $sql .= "-- --------------------------------------------------------\n";
        $sql .= "DROP TABLE IF EXISTS `{$table}`;\n";

        $res_create = mysqli_query($koneksi, "SHOW CREATE TABLE `{$table}`");
        if ($res_create && $row_create = mysqli_fetch_row($res_create)) {
            $sql .= $row_create[1] . ";\n\n";
        }

        // Ambil daftar kolom tabel untuk INSERT presisi
        $cols = [];
        $res_cols = mysqli_query($koneksi, "SHOW COLUMNS FROM `{$table}`");
        if ($res_cols) {
            while ($c = mysqli_fetch_assoc($res_cols)) {
                $cols[] = "`" . $c['Field'] . "`";
            }
        }
        $cols_sql = implode(', ', $cols);

        // Ambil Data Tabel
        $res_data = mysqli_query($koneksi, "SELECT * FROM `{$table}`");
        $num_rows = $res_data ? mysqli_num_rows($res_data) : 0;
        if ($num_rows > 0) {
            $sql .= "-- Dumping data untuk tabel `{$table}` ({$num_rows} baris)\n";

            $rows_batch = [];
            $batch_count = 0;
            while ($row = mysqli_fetch_row($res_data)) {
                $values = [];
                foreach ($row as $val) {
                    if (is_null($val)) {
                        $values[] = "NULL";
                    } else {
                        // Escape string & aman dari baris baru
                        $escaped = mysqli_real_escape_string($koneksi, $val);
                        $escaped = str_replace(["\r", "\n"], ["\\r", "\\n"], $escaped);
                        $values[] = "'" . $escaped . "'";
                    }
                }
                $rows_batch[] = "(" . implode(", ", $values) . ")";
                $batch_count++;

                // Pecah dalam batch per 100 baris agar aman dari limit packet
                if ($batch_count >= 100) {
                    $sql .= "INSERT INTO `{$table}` ({$cols_sql}) VALUES \n" . implode(",\n", $rows_batch) . ";\n";
                    $rows_batch = [];
                    $batch_count = 0;
                }
            }

            if (!empty($rows_batch)) {
                $sql .= "INSERT INTO `{$table}` ({$cols_sql}) VALUES \n" . implode(",\n", $rows_batch) . ";\n";
            }
            $sql .= "\n";
        }
    }

    $sql .= "COMMIT;\n";
    $sql .= "SET FOREIGN_KEY_CHECKS = 1;\n";
    $sql .= "-- ================= Akhir File Backup ==================\n";
    return $sql;
}

// -------------------------------------------------------------
// ACTION 1: UNDUH SQL LANGSUNG KE BROWSER (1-KLIK)
// -------------------------------------------------------------
if (isset($_GET['action']) && $_GET['action'] === 'download_now') {
    $filename = 'zafanasnack_backup_' . date('Y-m-d_His') . '.sql';
    $sql_content = generate_sql_dump($koneksi);

    // Simpan salinan ke folder backups/
    @file_put_contents($backup_dir . $filename, $sql_content);

    // Bersihkan seluruh output buffer agar tidak ada spasi/HTML yang tercampur
    while (ob_get_level()) {
        ob_end_clean();
    }

    header('Content-Description: File Transfer');
    header('Content-Type: application/sql; charset=utf-8');
    header('Content-Disposition: attachment; filename="' . $filename . '"');
    header('Content-Transfer-Encoding: binary');
    header('Expires: 0');
    header('Cache-Control: must-revalidate, post-check=0, pre-check=0');
    header('Pragma: public');
    header('Content-Length: ' . strlen($sql_content));
    echo $sql_content;
    exit;
}

// -------------------------------------------------------------
// ACTION 2: UNDUH FILE CADANGAN TERSIMPAN DARI DAFTAR RIWAYAT
// -------------------------------------------------------------
if (isset($_GET['action']) && $_GET['action'] === 'get_file') {
    $file = basename($_GET['file'] ?? '');
    $filepath = $backup_dir . $file;
    if (!empty($file) && file_exists($filepath) && str_ends_with(strtolower($file), '.sql')) {
        while (ob_get_level()) {
            ob_end_clean();
        }

        header('Content-Description: File Transfer');
        header('Content-Type: application/sql; charset=utf-8');
        header('Content-Disposition: attachment; filename="' . $file . '"');
        header('Content-Transfer-Encoding: binary');
        header('Expires: 0');
        header('Cache-Control: must-revalidate, post-check=0, pre-check=0');
        header('Pragma: public');
        header('Content-Length: ' . filesize($filepath));
        readfile($filepath);
        exit;
    } else {
        set_flash('error', 'File backup tidak ditemukan atau format tidak valid.');
        header("Location: " . BASE_URL . "admin/backup.php");
        exit;
    }
}

// -------------------------------------------------------------
// ACTION 3: BUAT SALINAN CADANGAN BARU DI SERVER
// -------------------------------------------------------------
if (isset($_POST['action']) && $_POST['action'] === 'create_backup') {
    $filename = 'zafanasnack_backup_' . date('Y-m-d_His') . '.sql';
    $sql_content = generate_sql_dump($koneksi);
    if (@file_put_contents($backup_dir . $filename, $sql_content) !== false) {
        set_flash('success', "File cadangan baru <strong>{$filename}</strong> (" . round(strlen($sql_content) / 1024, 2) . " KB) berhasil dibuat dan tersimpan aman di server!");
    } else {
        set_flash('error', "Gagal menyimpan file backup ke folder server.");
    }
    header("Location: " . BASE_URL . "admin/backup.php");
    exit;
}

// -------------------------------------------------------------
// ACTION 4: HAPUS FILE CADANGAN
// -------------------------------------------------------------
if (isset($_GET['action']) && $_GET['action'] === 'delete_file') {
    $file = basename($_GET['file'] ?? '');
    $filepath = $backup_dir . $file;
    if (!empty($file) && file_exists($filepath) && str_ends_with(strtolower($file), '.sql')) {
        @unlink($filepath);
        set_flash('success', "File cadangan {$file} berhasil dihapus dari server.");
    }
    header("Location: " . BASE_URL . "admin/backup.php");
    exit;
}

// =============================================================
// TAMPILAN HALAMAN (HANYA DITAMPILKAN JIKA BUKAN PROSES DOWNLOAD)
// =============================================================
$admin_page_title = "Backup & Pemulihan Database";
require_once __DIR__ . '/includes/header.php';
require_once __DIR__ . '/includes/sidebar.php';

// Ambil daftar file backup yang ada
$backup_files = [];
if (is_dir($backup_dir)) {
    $scanned = scandir($backup_dir, SCANDIR_SORT_DESCENDING);
    foreach ($scanned as $f) {
        if ($f !== '.' && $f !== '..' && str_ends_with(strtolower($f), '.sql')) {
            $fpath = $backup_dir . $f;
            $backup_files[] = [
                'name' => $f,
                'size' => round(filesize($fpath) / 1024, 2) . ' KB',
                'time' => date('d M Y, H:i', filemtime($fpath))
            ];
        }
    }
}

// Statistik Ringkas Database
$stat_produk = mysqli_fetch_assoc(mysqli_query($koneksi, "SELECT COUNT(*) as c FROM produk"))['c'] ?? 0;
$stat_kategori = mysqli_fetch_assoc(mysqli_query($koneksi, "SELECT COUNT(*) as c FROM kategori"))['c'] ?? 0;
$stat_pesanan = mysqli_fetch_assoc(mysqli_query($koneksi, "SELECT COUNT(*) as c FROM pesanan"))['c'] ?? 0;
$stat_users = mysqli_fetch_assoc(mysqli_query($koneksi, "SELECT COUNT(*) as c FROM users"))['c'] ?? 0;
?>

<main class="admin-main">
  <div class="admin-topbar">
    <div>
      <h2 style="font-size: 20px; font-weight: 800; color: var(--navy);">Sistem Backup Database</h2>
      <p style="font-size: 13px; color: var(--navy-light);">Unduh dan amankan seluruh data produk, pelanggan, pesanan, dan pengaturan website</p>
    </div>
    <div style="display: flex; gap: 10px;">
      <a href="<?= BASE_URL ?>admin/backup.php?action=download_now" class="btn btn-sm btn-primary">
        <i class="fa-solid fa-cloud-arrow-down"></i> Unduh SQL Sekarang (1-Klik)
      </a>
    </div>
  </div>

  <div class="admin-body">
    <?= get_flash() ?>

    <!-- Ringkasan Statistik Database -->
    <div style="display: grid; grid-template-columns: repeat(auto-fit, minmax(200px, 1fr)); gap: 16px; margin-bottom: 25px;">
      <div class="card" style="padding: 16px; display: flex; align-items: center; gap: 14px;">
        <div style="width: 44px; height: 44px; border-radius: 10px; background: #DBEAFE; color: #2563EB; display: flex; align-items: center; justify-content: center; font-size: 20px;">
          <i class="fa-solid fa-cookie"></i>
        </div>
        <div>
          <span style="font-size: 11px; color: var(--navy-light); text-transform: uppercase; font-weight: 700;">Total Produk</span>
          <h3 style="font-size: 18px; color: var(--navy); margin: 0;"><?= $stat_produk ?> Item</h3>
        </div>
      </div>

      <div class="card" style="padding: 16px; display: flex; align-items: center; gap: 14px;">
        <div style="width: 44px; height: 44px; border-radius: 10px; background: #FEF3C7; color: #D97706; display: flex; align-items: center; justify-content: center; font-size: 20px;">
          <i class="fa-solid fa-tags"></i>
        </div>
        <div>
          <span style="font-size: 11px; color: var(--navy-light); text-transform: uppercase; font-weight: 700;">Kategori</span>
          <h3 style="font-size: 18px; color: var(--navy); margin: 0;"><?= $stat_kategori ?> Kategori</h3>
        </div>
      </div>

      <div class="card" style="padding: 16px; display: flex; align-items: center; gap: 14px;">
        <div style="width: 44px; height: 44px; border-radius: 10px; background: #DCFCE7; color: #16A34A; display: flex; align-items: center; justify-content: center; font-size: 20px;">
          <i class="fa-solid fa-receipt"></i>
        </div>
        <div>
          <span style="font-size: 11px; color: var(--navy-light); text-transform: uppercase; font-weight: 700;">Pesanan</span>
          <h3 style="font-size: 18px; color: var(--navy); margin: 0;"><?= $stat_pesanan ?> Transaksi</h3>
        </div>
      </div>

      <div class="card" style="padding: 16px; display: flex; align-items: center; gap: 14px;">
        <div style="width: 44px; height: 44px; border-radius: 10px; background: #F3E8FF; color: #9333EA; display: flex; align-items: center; justify-content: center; font-size: 20px;">
          <i class="fa-solid fa-users"></i>
        </div>
        <div>
          <span style="font-size: 11px; color: var(--navy-light); text-transform: uppercase; font-weight: 700;">Pengguna / Akun</span>
          <h3 style="font-size: 18px; color: var(--navy); margin: 0;"><?= $stat_users ?> User</h3>
        </div>
      </div>
    </div>

    <div style="display: grid; grid-template-columns: 2fr 1fr; gap: 25px; align-items: start;">
      
      <!-- Tabel Riwayat File Cadangan -->
      <div class="card" style="padding: 0; overflow: hidden;">
        <div style="padding: 16px 20px; border-bottom: 1px solid var(--border-color); display: flex; justify-content: space-between; align-items: center;">
          <h3 style="font-size: 16px; color: var(--navy); margin: 0;">
            <i class="fa-solid fa-database text-blue"></i> Riwayat File Backup di Server (<?= count($backup_files) ?>)
          </h3>
          <form action="<?= BASE_URL ?>admin/backup.php" method="POST" style="margin: 0;">
            <input type="hidden" name="action" value="create_backup">
            <button type="submit" class="btn btn-sm btn-light">
              <i class="fa-solid fa-plus"></i> Buat Cadangan Baru
            </button>
          </form>
        </div>

        <div class="table-responsive">
          <table class="table">
            <thead>
              <tr>
                <th>Nama File SQL</th>
                <th>Ukuran</th>
                <th>Waktu Dibuat</th>
                <th style="text-align: center; width: 140px;">Aksi</th>
              </tr>
            </thead>
            <tbody>
              <?php if (!empty($backup_files)): ?>
                <?php foreach ($backup_files as $bf): ?>
                  <tr>
                    <td>
                      <i class="fa-regular fa-file-code text-blue" style="margin-right: 6px;"></i>
                      <strong><?= htmlspecialchars($bf['name']) ?></strong>
                    </td>
                    <td><?= $bf['size'] ?></td>
                    <td style="font-size: 13px; color: var(--navy-light);"><?= $bf['time'] ?></td>
                    <td style="text-align: center; white-space: nowrap;">
                      <a href="<?= BASE_URL ?>admin/backup.php?action=get_file&file=<?= urlencode($bf['name']) ?>" class="btn btn-sm btn-primary" style="padding: 4px 8px;" title="Unduh File SQL">
                        <i class="fa-solid fa-download"></i> Unduh
                      </a>
                      <a href="<?= BASE_URL ?>admin/backup.php?action=delete_file&file=<?= urlencode($bf['name']) ?>" class="btn btn-sm btn-confirm-delete" style="padding: 4px 8px; color: #EF4444;" title="Hapus File Cadangan">
                        <i class="fa-solid fa-trash-can"></i>
                      </a>
                    </td>
                  </tr>
                <?php endforeach; ?>
              <?php else: ?>
                <tr>
                  <td colspan="4" style="text-align: center; padding: 40px; color: var(--navy-light);">
                    Belum ada salinan backup di server. Klik tombol <strong>"Unduh SQL Sekarang"</strong> di atas atau tombol <strong>"Buat Cadangan Baru"</strong> untuk membuat file cadangan.
                  </td>
                </tr>
              <?php endif; ?>
            </tbody>
          </table>
        </div>
      </div>

      <!-- Panduan Pemulihan / Import Database -->
      <div>
        <div class="card" style="background: #F8FAFC; border: 1px solid #E2E8F0; margin-bottom: 20px;">
          <h4 style="font-size: 15px; font-weight: 700; color: var(--navy); margin-bottom: 12px;">
            <i class="fa-solid fa-circle-question text-blue"></i> Cara Menggunakan File Backup
          </h4>
          <ol style="font-size: 12px; color: var(--navy); padding-left: 18px; line-height: 1.8; margin-bottom: 0;">
            <li>Unduh file backup <code>.sql</code> melalui tombol <strong>Unduh SQL Sekarang</strong> di atas.</li>
            <li>Buka <strong>cPanel</strong> hosting Anda, lalu buka <strong>phpMyAdmin</strong>.</li>
            <li>Pilih database toko Anda pada panel sebelah kiri.</li>
            <li>Klik menu <strong>Import</strong> di bagian atas layar phpMyAdmin.</li>
            <li>Klik <em>Choose File</em> dan pilih file <code>.sql</code> yang telah diunduh.</li>
            <li>Klik tombol <strong>Import / Kirim</strong> di bagian bawah halaman.</li>
          </ol>
        </div>

        <div class="card" style="background: #EFF6FF; border: 1px solid #BFDBFE;">
          <h4 style="font-size: 14px; font-weight: 700; color: #1E40AF; margin-bottom: 8px;">
            <i class="fa-solid fa-shield-halved text-blue"></i> Keamanan File Backup
          </h4>
          <p style="font-size: 12px; color: #1E3A8A; line-height: 1.6; margin-bottom: 0;">
            Folder penyimpanan cadangan (<code>/backups/</code>) telah dilengkapi file <code>.htaccess</code> pengaman, sehingga data database tidak dapat diunduh oleh pengunjung umum melalui link publik.
          </p>
        </div>
      </div>

    </div>
  </div>
</main>

<?php require_once __DIR__ . '/includes/footer.php'; ?>
