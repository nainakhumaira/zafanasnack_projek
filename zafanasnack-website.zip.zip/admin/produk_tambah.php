<?php
$admin_page_title = "Tambah Produk Snack Baru";
require_once __DIR__ . '/includes/header.php';
require_once __DIR__ . '/includes/sidebar.php';

$error = '';
$kategori_list = mysqli_query($koneksi, "SELECT * FROM kategori ORDER BY CASE WHEN slug = 'original-gurih' THEN 1 WHEN slug = 'peyek-kacang' THEN 2 WHEN slug = 'peyek-udang' THEN 3 WHEN slug = 'peyek-kacang-kedelai' THEN 4 ELSE 5 END, nama_kategori ASC");

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $id_kategori = (int)($_POST['id_kategori'] ?? 0);
    $nama_produk = trim($_POST['nama_produk'] ?? '');
    $deskripsi = trim($_POST['deskripsi'] ?? '');
    $harga = (int)($_POST['harga'] ?? 0);
    $harga_coret = (int)($_POST['harga_coret'] ?? 0);
    $berat_gram = (int)($_POST['berat_gram'] ?? 150);
    $stok = (int)($_POST['stok'] ?? 0);
    $status = $_POST['status'] ?? 'aktif';
    $is_best_seller = isset($_POST['is_best_seller']) ? 1 : 0;
    $is_promo = isset($_POST['is_promo']) ? 1 : 0;

    if (empty($nama_produk) || $id_kategori <= 0 || $harga <= 0) {
        $error = 'Nama snack, kategori, dan harga jual wajib diisi!';
    } else {
        // Generate slug unik
        $base_slug = slugify($nama_produk);
        $slug = $base_slug;
        $counter = 1;
        while (true) {
            $check = mysqli_query($koneksi, "SELECT id_produk FROM produk WHERE slug = '$slug'");
            if (mysqli_num_rows($check) == 0) break;
            $slug = $base_slug . '-' . $counter;
            $counter++;
        }

        // Upload foto produk menggunakan helper dengan validasi ketat (MIME, Ukuran Max 5MB, format aman)
        $foto_name = 'default_snack.jpg';
        $upload_error = null;

        if (isset($_FILES['foto']) && $_FILES['foto']['error'] !== UPLOAD_ERR_NO_FILE) {
            $uploaded_file = handle_product_image_upload($_FILES['foto'], $upload_error);
            if ($uploaded_file === false) {
                $error = $upload_error ?? 'Gagal mengunggah foto produk.';
            } else if ($uploaded_file !== null) {
                $foto_name = $uploaded_file;
            }
        }

        if (empty($error)) {
            $stmt = mysqli_prepare($koneksi, "INSERT INTO produk (id_kategori, nama_produk, slug, deskripsi, harga, harga_coret, berat_gram, stok, foto, is_best_seller, is_promo, status) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)");
            mysqli_stmt_bind_param($stmt, "isssiiiisiis", $id_kategori, $nama_produk, $slug, $deskripsi, $harga, $harga_coret, $berat_gram, $stok, $foto_name, $is_best_seller, $is_promo, $status);

            if (mysqli_stmt_execute($stmt)) {
                set_flash('success', 'Produk snack baru "' . htmlspecialchars($nama_produk) . '" berhasil ditambahkan dan langsung aktif di Beranda & Katalog!');
                header("Location: " . BASE_URL . "admin/produk.php");
                exit;
            } else {
                $error = 'Gagal menyimpan produk ke database. Silakan coba kembali.';
            }
        }
    }
}
?>

<main class="admin-main">
  <div class="admin-topbar">
    <div>
      <h2 style="font-size: 20px; font-weight: 800; color: var(--navy);">Tambah Camilan Baru</h2>
      <p style="font-size: 13px; color: var(--navy-light);">Lengkapi formulir untuk memasukkan varian snack ke katalog</p>
    </div>
    <a href="<?= BASE_URL ?>admin/produk.php" class="btn btn-sm btn-outline">
      <i class="fa-solid fa-arrow-left"></i> Kembali ke Daftar
    </a>
  </div>

  <div class="admin-body">
    <?php if (!empty($error)): ?>
      <div class="alert alert-danger"><?= htmlspecialchars($error) ?></div>
    <?php endif; ?>

    <div class="card" style="max-width: 800px;">
      <form action="<?= BASE_URL ?>admin/produk_tambah.php" method="POST" enctype="multipart/form-data">
        <div class="form-group">
          <label class="form-label">Nama Camilan / Snack *</label>
          <input type="text" name="nama_produk" class="form-control" placeholder="Contoh: Keripik Pisang Cokelat Lumer" value="<?= htmlspecialchars($_POST['nama_produk'] ?? '') ?>" required>
        </div>

        <div style="display: grid; grid-template-columns: 1fr 1fr; gap: 20px;">
          <div class="form-group">
            <label class="form-label">Kategori Snack *</label>
            <select name="id_kategori" class="form-control" required>
              <option value="">-- Pilih Kategori --</option>
              <?php while ($k = mysqli_fetch_assoc($kategori_list)): ?>
                <option value="<?= $k['id_kategori'] ?>"><?= htmlspecialchars($k['nama_kategori']) ?></option>
              <?php endwhile; ?>
            </select>
          </div>

          <div class="form-group">
            <label class="form-label">Harga Jual (Rp) *</label>
            <input type="number" name="harga" class="form-control" placeholder="18000" min="1000" value="<?= htmlspecialchars($_POST['harga'] ?? '') ?>" required>
          </div>
        </div>

        <div style="display: grid; grid-template-columns: 1fr 1fr 1fr; gap: 20px;">
          <div class="form-group">
            <label class="form-label">Harga Coret / Asli (Opsional)</label>
            <input type="number" name="harga_coret" class="form-control" placeholder="22000" value="<?= htmlspecialchars($_POST['harga_coret'] ?? '') ?>">
            <small style="color: var(--navy-light); font-size: 11px;">Untuk menampilkan diskon (misal Rp 22.000 jadi Rp 18.000)</small>
          </div>

          <div class="form-group">
            <label class="form-label">Berat Bersih (gram)</label>
            <input type="number" name="berat_gram" class="form-control" placeholder="150" value="150">
          </div>

          <div class="form-group">
            <label class="form-label">Jumlah Stok Awal</label>
            <input type="number" name="stok" class="form-control" placeholder="30" value="30" min="0">
          </div>
        </div>

        <div style="display: grid; grid-template-columns: 1fr 1fr; gap: 20px; margin-bottom: 15px;">
          <div class="form-group">
            <label class="form-label">Status Produk</label>
            <select name="status" class="form-control">
              <option value="aktif">Aktif (Tampil di Katalog)</option>
              <option value="nonaktif">Nonaktif (Sembunyikan)</option>
            </select>
          </div>

          <div style="display: flex; gap: 20px; align-items: center; padding-top: 25px;">
            <label style="display: flex; align-items: center; gap: 8px; font-weight: 600; cursor: pointer;">
              <input type="checkbox" name="is_best_seller" value="1"> Best Seller 🔥
            </label>
            <label style="display: flex; align-items: center; gap: 8px; font-weight: 600; cursor: pointer;">
              <input type="checkbox" name="is_promo" value="1"> Promo Diskon ⚡
            </label>
          </div>
        </div>

        <div class="form-group">
          <label class="form-label">Deskripsi Lengkap Snack</label>
          <textarea name="deskripsi" class="form-control" rows="4" placeholder="Jelaskan cita rasa, tekstur kerenyahan, keunggulan bahan rempah, atau saran penyajian..."><?= htmlspecialchars($_POST['deskripsi'] ?? '') ?></textarea>
        </div>

        <div class="form-group">
          <label class="form-label" style="font-weight: 700; color: var(--navy);">
            <i class="fa-solid fa-camera text-blue"></i> Upload Foto Produk dari Komputer
          </label>
          <div style="background: var(--soft-gray); border: 2px dashed #93C5FD; border-radius: var(--radius-md); padding: 20px; text-align: center; position: relative; transition: all 0.2s;">
            <input type="file" name="foto" class="form-control" accept=".jpg,.jpeg,.png,.webp,image/jpeg,image/png,image/webp" id="fotoInput" style="cursor: pointer;">
            <div style="margin-top: 8px; font-size: 12px; color: var(--navy-light);">
              <i class="fa-solid fa-circle-info text-blue"></i> Mendukung format: <strong>JPG, JPEG, PNG, WEBP</strong> &bull; Maksimal: <strong>5 MB</strong>
            </div>
          </div>
          
          <!-- Box Live Preview Gambar -->
          <div id="fotoPreviewBox" style="margin-top: 15px; display: none; padding: 15px; background: #fff; border-radius: var(--radius-sm); border: 1px solid var(--border-color); box-shadow: var(--shadow-sm);">
            <div style="font-size: 13px; font-weight: 700; color: var(--navy); margin-bottom: 8px;">
              <i class="fa-solid fa-eye text-blue"></i> Preview Gambar Produk:
            </div>
            <div style="display: flex; align-items: center; gap: 16px; flex-wrap: wrap;">
              <div style="width: 120px; height: 120px; border-radius: 8px; overflow: hidden; border: 1px solid var(--border-color); background: #F8FAFC; display: flex; align-items: center; justify-content: center;">
                <img id="fotoPreview" src="" alt="Preview Foto" style="max-width: 100%; max-height: 100%; object-fit: contain;">
              </div>
              <div>
                <div id="previewFileName" style="font-weight: 700; color: var(--navy); font-size: 13px;"></div>
                <div id="previewFileSize" style="color: var(--navy-light); font-size: 12px; margin-top: 2px;"></div>
                <button type="button" id="btnHapusPreview" class="btn btn-sm btn-outline" style="margin-top: 8px; color: #EF4444; border-color: #FCA5A5;">
                  <i class="fa-solid fa-xmark"></i> Batal / Pilih Foto Lain
                </button>
              </div>
            </div>
          </div>
        </div>

        <div style="margin-top: 25px; display: flex; gap: 12px;">
          <button type="submit" class="btn btn-primary btn-lg">
            <i class="fa-solid fa-floppy-disk"></i> Simpan Produk
          </button>
          <a href="<?= BASE_URL ?>admin/produk.php" class="btn btn-light btn-lg">Batal</a>
        </div>
      </form>
    </div>

    <script>
      const fotoInput = document.getElementById('fotoInput');
      const fotoPreviewBox = document.getElementById('fotoPreviewBox');
      const fotoPreview = document.getElementById('fotoPreview');
      const previewFileName = document.getElementById('previewFileName');
      const previewFileSize = document.getElementById('previewFileSize');
      const btnHapusPreview = document.getElementById('btnHapusPreview');

      if (fotoInput) {
        fotoInput.addEventListener('change', function () {
          const file = this.files[0];
          if (file) {
            // Validasi ukuran client-side 5MB
            if (file.size > 5 * 1024 * 1024) {
              alert('Ukuran file melebihi 5 MB. Harap pilih gambar yang lebih kecil.');
              this.value = '';
              fotoPreviewBox.style.display = 'none';
              return;
            }

            const reader = new FileReader();
            reader.onload = function (e) {
              fotoPreview.src = e.target.result;
              previewFileName.textContent = file.name;
              previewFileSize.textContent = (file.size / 1024).toFixed(1) + ' KB (' + file.type + ')';
              fotoPreviewBox.style.display = 'block';
            }
            reader.readAsDataURL(file);
          } else {
            fotoPreviewBox.style.display = 'none';
          }
        });
      }

      if (btnHapusPreview) {
        btnHapusPreview.addEventListener('click', function () {
          fotoInput.value = '';
          fotoPreviewBox.style.display = 'none';
          fotoPreview.src = '';
        });
      }
    </script>

<?php require_once __DIR__ . '/includes/footer.php'; ?>
