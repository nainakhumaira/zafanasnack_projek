<?php
$admin_page_title = "Kelola Kategori Snack";
require_once __DIR__ . '/includes/header.php';
require_once __DIR__ . '/includes/sidebar.php';

// 1. TAMBAH KATEGORI
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['action']) && $_POST['action'] === 'tambah') {
    $nama_kategori = trim($_POST['nama_kategori'] ?? '');
    $ikon = trim($_POST['ikon'] ?? 'fa-cookie');
    if (!empty($nama_kategori)) {
        $slug = slugify($nama_kategori);
        $stmt = mysqli_prepare($koneksi, "INSERT INTO kategori (nama_kategori, slug, ikon) VALUES (?, ?, ?)");
        mysqli_stmt_bind_param($stmt, "sss", $nama_kategori, $slug, $ikon);
        if (mysqli_stmt_execute($stmt)) {
            set_flash('success', 'Kategori "' . htmlspecialchars($nama_kategori) . '" berhasil ditambahkan!');
        } else {
            set_flash('danger', 'Gagal menambahkan kategori. Mungkin nama sudah ada.');
        }
    }
    header("Location: " . BASE_URL . "admin/kategori.php");
    exit;
}

// 2. EDIT KATEGORI
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['action']) && $_POST['action'] === 'edit') {
    $id_kat = (int)($_POST['id_kategori'] ?? 0);
    $nama_kategori = trim($_POST['nama_kategori'] ?? '');
    $ikon = trim($_POST['ikon'] ?? 'fa-cookie');
    if (!empty($nama_kategori) && $id_kat > 0) {
        $slug = slugify($nama_kategori);
        $stmt = mysqli_prepare($koneksi, "UPDATE kategori SET nama_kategori = ?, slug = ?, ikon = ? WHERE id_kategori = ?");
        mysqli_stmt_bind_param($stmt, "sssi", $nama_kategori, $slug, $ikon, $id_kat);
        if (mysqli_stmt_execute($stmt)) {
            set_flash('success', 'Kategori berhasil diperbarui menjadi "' . htmlspecialchars($nama_kategori) . '"!');
        } else {
            set_flash('danger', 'Gagal memperbarui kategori.');
        }
    }
    header("Location: " . BASE_URL . "admin/kategori.php");
    exit;
}

// 3. HAPUS KATEGORI
if (isset($_GET['action']) && $_GET['action'] === 'hapus') {
    $id_kat = (int)($_GET['id'] ?? 0);
    // Cek apakah ada produk yang masih menggunakan kategori ini
    $cek_produk = mysqli_query($koneksi, "SELECT COUNT(*) as total FROM produk WHERE id_kategori = $id_kat");
    $d_cek = mysqli_fetch_assoc($cek_produk);

    if ($d_cek && $d_cek['total'] > 0) {
        set_flash('danger', 'Kategori tidak dapat dihapus karena masih memiliki ' . $d_cek['total'] . ' produk terdaftar. Ubah kategori produknya terlebih dahulu.');
    } else {
        mysqli_query($koneksi, "DELETE FROM kategori WHERE id_kategori = $id_kat");
        set_flash('success', 'Kategori berhasil dihapus.');
    }
    header("Location: " . BASE_URL . "admin/kategori.php");
    exit;
}

// Mode Edit jika ada parameter GET edit
$is_edit = false;
$edit_kat = null;
if (isset($_GET['edit'])) {
    $id_edit = (int)$_GET['edit'];
    $q_edit = mysqli_query($koneksi, "SELECT * FROM kategori WHERE id_kategori = $id_edit");
    if ($q_edit && mysqli_num_rows($q_edit) > 0) {
        $edit_kat = mysqli_fetch_assoc($q_edit);
        $is_edit = true;
    }
}

// Ambil daftar kategori beserta jumlah produk
$query = "SELECT k.*, COUNT(p.id_produk) as total_produk 
          FROM kategori k 
          LEFT JOIN produk p ON k.id_kategori = p.id_kategori 
          GROUP BY k.id_kategori 
          ORDER BY k.id_kategori ASC";
$result = mysqli_query($koneksi, $query);

$available_icons = [
    'fa-bowl-food' => 'Mangkuk / Gurih (fa-bowl-food)',
    'fa-seedling' => 'Biji-bijian / Peyek Kacang (fa-seedling)',
    'fa-shrimp' => 'Udang / Peyek Udang (fa-shrimp)',
    'fa-leaf' => 'Daun / Kedelai (fa-leaf)',
    'fa-cookie' => 'Kue / Camilan (fa-cookie)',
    'fa-cookie-bite' => 'Cookies (fa-cookie-bite)',
    'fa-pepper-hot' => 'Cabai Pedas (fa-pepper-hot)',
    'fa-fire' => 'Super Pedas (fa-fire)',
    'fa-utensils' => 'Tradisional (fa-utensils)'
];
?>

<main class="admin-main">
  <div class="admin-topbar">
    <div>
      <h2 style="font-size: 20px; font-weight: 800; color: var(--navy);">Kelola Kategori Camilan</h2>
      <p style="font-size: 13px; color: var(--navy-light);">Atur kategori utama ZAFANA SNACK agar produk tertata rapi di katalog dan beranda</p>
    </div>
  </div>

  <div class="admin-body">
    <?= get_flash() ?>

    <div style="display: grid; grid-template-columns: 1fr 2fr; gap: 25px; align-items: start;">
      
      <!-- Form Tambah / Edit Kategori -->
      <div class="card">
        <div class="card-header">
          <h3>
            <?php if ($is_edit): ?>
              <i class="fa-solid fa-pen-to-square text-blue"></i> Edit Kategori
            <?php else: ?>
              <i class="fa-solid fa-plus-circle text-blue"></i> Tambah Kategori Baru
            <?php endif; ?>
          </h3>
        </div>
        <form action="<?= BASE_URL ?>admin/kategori.php" method="POST">
          <input type="hidden" name="action" value="<?= $is_edit ? 'edit' : 'tambah' ?>">
          <?php if ($is_edit): ?>
            <input type="hidden" name="id_kategori" value="<?= $edit_kat['id_kategori'] ?>">
          <?php endif; ?>

          <div class="form-group">
            <label class="form-label">Nama Kategori *</label>
            <input type="text" name="nama_kategori" class="form-control" placeholder="Contoh: Peyek Kacang" value="<?= htmlspecialchars($is_edit ? $edit_kat['nama_kategori'] : '') ?>" required>
            <small style="color: var(--navy-light); font-size: 11px;">URL Slug akan digenerate otomatis.</small>
          </div>

          <div class="form-group">
            <label class="form-label">Ikon Kategori</label>
            <select name="ikon" class="form-control">
              <?php foreach ($available_icons as $ico_class => $ico_label): ?>
                <?php 
                  $selected = ($is_edit && ($edit_kat['ikon'] ?? '') === $ico_class) ? 'selected' : '';
                ?>
                <option value="<?= $ico_class ?>" <?= $selected ?>><?= $ico_label ?></option>
              <?php endforeach; ?>
            </select>
          </div>

          <div style="display: flex; gap: 10px; margin-top: 20px;">
            <button type="submit" class="btn btn-primary btn-block">
              <i class="fa-solid fa-save"></i> <?= $is_edit ? 'Simpan Perubahan' : 'Simpan Kategori' ?>
            </button>
            <?php if ($is_edit): ?>
              <a href="<?= BASE_URL ?>admin/kategori.php" class="btn btn-light" style="padding: 10px 14px;">Batal</a>
            <?php endif; ?>
          </div>
        </form>
      </div>

      <!-- Tabel Daftar Kategori -->
      <div class="card" style="padding: 0; overflow: hidden;">
        <div class="card-header" style="padding: 16px 20px; margin-bottom: 0; display: flex; justify-content: space-between; align-items: center;">
          <h3 style="margin: 0;">Daftar Kategori Tersedia (<?= mysqli_num_rows($result) ?>)</h3>
        </div>
        <div class="table-responsive">
          <table class="table">
            <thead>
              <tr>
                <th style="width: 50px;">No</th>
                <th>Ikon & Kategori</th>
                <th>Slug URL</th>
                <th>Total Produk</th>
                <th style="text-align: center; width: 100px;">Aksi</th>
              </tr>
            </thead>
            <tbody>
              <?php if ($result && mysqli_num_rows($result) > 0): $no = 1; ?>
                <?php while ($kat = mysqli_fetch_assoc($result)): ?>
                  <tr>
                    <td><?= $no++ ?></td>
                    <td>
                      <div style="display: flex; align-items: center; gap: 10px;">
                        <span style="width: 32px; height: 32px; border-radius: 8px; background: var(--light-blue); color: var(--primary-blue); display: flex; align-items: center; justify-content: center; font-size: 14px;">
                          <i class="fa-solid <?= htmlspecialchars($kat['ikon'] ?? 'fa-cookie') ?>"></i>
                        </span>
                        <strong style="color: var(--navy);"><?= htmlspecialchars($kat['nama_kategori']) ?></strong>
                      </div>
                    </td>
                    <td><code style="background: var(--light-blue); color: var(--primary-blue); padding: 3px 8px; border-radius: 4px; font-size: 12px;"><?= htmlspecialchars($kat['slug']) ?></code></td>
                    <td>
                      <span style="font-weight: 700; color: var(--navy); background: var(--soft-gray); padding: 3px 10px; border-radius: 20px; font-size: 12px;"><?= (int)$kat['total_produk'] ?> snack</span>
                    </td>
                    <td style="text-align: center;">
                      <a href="<?= BASE_URL ?>admin/kategori.php?edit=<?= $kat['id_kategori'] ?>" class="btn btn-sm btn-light" style="padding: 4px 8px; margin-right: 4px;" title="Edit Kategori">
                        <i class="fa-solid fa-pen-to-square"></i>
                      </a>
                      <a href="<?= BASE_URL ?>admin/kategori.php?action=hapus&id=<?= $kat['id_kategori'] ?>" class="btn btn-sm btn-confirm-delete" style="padding: 4px 8px; color: #EF4444;" title="Hapus Kategori">
                        <i class="fa-solid fa-trash-can"></i>
                      </a>
                    </td>
                  </tr>
                <?php endwhile; ?>
              <?php else: ?>
                <tr>
                  <td colspan="5" style="text-align: center; padding: 30px; color: var(--navy-light);">Belum ada kategori.</td>
                </tr>
              <?php endif; ?>
            </tbody>
          </table>
        </div>
      </div>

    </div>
  </div>
</main>

<?php require_once __DIR__ . '/includes/footer.php'; ?>
