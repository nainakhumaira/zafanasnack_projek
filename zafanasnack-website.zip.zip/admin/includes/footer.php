    </div> <!-- /.admin-body -->
  </main> <!-- /.admin-main -->
</div> <!-- /.admin-layout -->

<script src="<?= BASE_URL ?>assets/js/main.js"></script>
</body>
</html>
