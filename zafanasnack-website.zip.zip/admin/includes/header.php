<?php
require_once __DIR__ . '/../../config/koneksi.php';

// Pastikan hanya role admin yang bisa membuka panel ini
if (!is_admin()) {
    header("Location: " . BASE_URL . "admin/login.php");
    exit;
}

$admin_user = current_user();
$admin_page_title = $admin_page_title ?? 'Admin Panel';
?>
<!DOCTYPE html>
<html lang="id">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title><?= htmlspecialchars($admin_page_title) ?> - ZAFANA SNACK</title>
  
  <!-- Google Fonts: Poppins & Inter -->
  <link rel="preconnect" href="https://fonts.googleapis.com">
  <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
  <link href="https://fonts.googleapis.com/css2?family=Inter:wght@400;500;600;700&family=Poppins:wght@500;600;700;800;900&display=swap" rel="stylesheet">
  
  <!-- Font Awesome Icons CDN -->
  <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.1/css/all.min.css">
  
  <!-- Chart.js CDN untuk Grafik Penjualan Interaktif -->
  <script src="https://cdn.jsdelivr.net/npm/chart.js"></script>

  <!-- Main Custom CSS & Admin CSS -->
  <link rel="stylesheet" href="<?= BASE_URL ?>assets/css/style.css?v=<?= time() ?>">
  <link rel="stylesheet" href="<?= BASE_URL ?>assets/css/admin.css?v=<?= time() ?>">
</head>
<body>
<div class="admin-layout">
