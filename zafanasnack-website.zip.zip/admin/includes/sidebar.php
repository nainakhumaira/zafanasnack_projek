<?php
$current_admin_page = basename($_SERVER['PHP_SELF']);
?>
<aside class="admin-sidebar">
  <div class="sidebar-brand">
    <i class="fa-solid fa-cookie-bite" style="color: #60A5FA;"></i>
    ZAFANA <span>ADMIN</span>
  </div>

  <ul class="sidebar-menu">
    <li class="sidebar-menu-title">Utama</li>
    <li>
      <a href="<?= BASE_URL ?>admin/index.php" class="sidebar-link <?= ($current_admin_page == 'index.php') ? 'active' : '' ?>">
        <i class="fa-solid fa-gauge"></i> Dashboard
      </a>
    </li>

    <li class="sidebar-menu-title">Master Data Camilan</li>
    <li>
      <a href="<?= BASE_URL ?>admin/kategori.php" class="sidebar-link <?= ($current_admin_page == 'kategori.php') ? 'active' : '' ?>">
        <i class="fa-solid fa-tags"></i> Kategori Produk
      </a>
    </li>
    <li>
      <a href="<?= BASE_URL ?>admin/produk.php" class="sidebar-link <?= ($current_admin_page == 'produk.php' || $current_admin_page == 'produk_tambah.php' || $current_admin_page == 'produk_edit.php') ? 'active' : '' ?>">
        <i class="fa-solid fa-box-archive"></i> Kelola Produk
      </a>
    </li>
    <li>
      <a href="<?= BASE_URL ?>admin/stok.php" class="sidebar-link <?= ($current_admin_page == 'stok.php') ? 'active' : '' ?>">
        <i class="fa-solid fa-boxes-stacked"></i> Pantau Stok
      </a>
    </li>

    <li class="sidebar-menu-title">Transaksi & User</li>
    <li>
      <a href="<?= BASE_URL ?>admin/pesanan.php" class="sidebar-link <?= ($current_admin_page == 'pesanan.php' || $current_admin_page == 'pesanan_detail.php') ? 'active' : '' ?>">
        <i class="fa-solid fa-cart-shopping"></i> Kelola Pesanan
      </a>
    </li>
    <li>
      <a href="<?= BASE_URL ?>admin/pelanggan.php" class="sidebar-link <?= ($current_admin_page == 'pelanggan.php') ? 'active' : '' ?>">
        <i class="fa-solid fa-users"></i> Data Pelanggan
      </a>
    </li>
    <li>
      <a href="<?= BASE_URL ?>admin/laporan.php" class="sidebar-link <?= ($current_admin_page == 'laporan.php') ? 'active' : '' ?>">
        <i class="fa-solid fa-file-invoice-dollar"></i> Laporan Penjualan
      </a>
    </li>

    <li class="sidebar-menu-title">Sistem & Pengaturan</li>
    <li>
      <a href="<?= BASE_URL ?>admin/pengaturan.php" class="sidebar-link <?= ($current_admin_page == 'pengaturan.php') ? 'active' : '' ?>">
        <i class="fa-solid fa-gear"></i> Pengaturan Toko
      </a>
    </li>
    <li>
      <a href="<?= BASE_URL ?>admin/backup.php" class="sidebar-link <?= ($current_admin_page == 'backup.php') ? 'active' : '' ?>">
        <i class="fa-solid fa-database"></i> Backup Database
      </a>
    </li>
  </ul>

  <div class="sidebar-footer">
    <a href="<?= BASE_URL ?>" target="_blank" class="sidebar-link" style="color: #60A5FA; padding: 8px 0;">
      <i class="fa-solid fa-arrow-up-right-from-square"></i> Lihat Web Toko
    </a>
    <a href="<?= BASE_URL ?>admin/logout.php" class="sidebar-link btn-confirm-delete" style="color: #F87171; padding: 8px 0;">
      <i class="fa-solid fa-right-from-bracket"></i> Keluar Admin
    </a>
  </div>
</aside>
