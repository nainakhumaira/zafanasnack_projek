<?php
$admin_page_title = "Kelola Pesanan Pelanggan";
require_once __DIR__ . '/includes/header.php';
require_once __DIR__ . '/includes/sidebar.php';

// FILTER STATUS
$status = trim($_GET['status'] ?? '');

$sql = "SELECT p.*, u.nama_lengkap, u.email 
        FROM pesanan p 
        JOIN users u ON p.id_user = u.id_user";

if (!empty($status)) {
    $sql .= " WHERE p.status_pesanan = '" . mysqli_real_escape_string($koneksi, $status) . "'";
}

$sql .= " ORDER BY p.id_pesanan DESC";
$result = mysqli_query($koneksi, $sql);

function badge_status_admin($st) {
    switch ($st) {
        case 'menunggu_pembayaran':
            return '<span style="background: #FEF3C7; color: #92400E; padding: 4px 10px; border-radius: 20px; font-size: 12px; font-weight: 700;">Menunggu Bayar</span>';
        case 'diproses':
            return '<span style="background: #DBEAFE; color: #1E40AF; padding: 4px 10px; border-radius: 20px; font-size: 12px; font-weight: 700;">Diproses</span>';
        case 'dikirim':
            return '<span style="background: #E0E7FF; color: #3730A3; padding: 4px 10px; border-radius: 20px; font-size: 12px; font-weight: 700;">Dikirim</span>';
        case 'selesai':
            return '<span style="background: #DCFCE7; color: #16A34A; padding: 4px 10px; border-radius: 20px; font-size: 12px; font-weight: 700;">Selesai</span>';
        case 'dibatalkan':
            return '<span style="background: #FEE2E2; color: #991B1B; padding: 4px 10px; border-radius: 20px; font-size: 12px; font-weight: 700;">Dibatalkan</span>';
        default:
            return htmlspecialchars($st);
    }
}
?>

<main class="admin-main">
  <div class="admin-topbar">
    <div>
      <h2 style="font-size: 20px; font-weight: 800; color: var(--navy);">Kelola Pesanan Masuk</h2>
      <p style="font-size: 13px; color: var(--navy-light);">Pantau verifikasi pembayaran, packing snack, dan update resi pengiriman</p>
    </div>
  </div>

  <div class="admin-body">
    <?= get_flash() ?>

    <!-- Filter Status Tabs -->
    <div style="display: flex; gap: 8px; flex-wrap: wrap; margin-bottom: 20px;">
      <a href="<?= BASE_URL ?>admin/pesanan.php" class="btn btn-sm <?= empty($status) ? 'btn-primary' : 'btn-light' ?>" style="border-radius: 20px;">Semua</a>
      <a href="<?= BASE_URL ?>admin/pesanan.php?status=menunggu_pembayaran" class="btn btn-sm <?= ($status == 'menunggu_pembayaran') ? 'btn-primary' : 'btn-light' ?>" style="border-radius: 20px;">Menunggu Bayar</a>
      <a href="<?= BASE_URL ?>admin/pesanan.php?status=diproses" class="btn btn-sm <?= ($status == 'diproses') ? 'btn-primary' : 'btn-light' ?>" style="border-radius: 20px;">Diproses</a>
      <a href="<?= BASE_URL ?>admin/pesanan.php?status=dikirim" class="btn btn-sm <?= ($status == 'dikirim') ? 'btn-primary' : 'btn-light' ?>" style="border-radius: 20px;">Dikirim</a>
      <a href="<?= BASE_URL ?>admin/pesanan.php?status=selesai" class="btn btn-sm <?= ($status == 'selesai') ? 'btn-primary' : 'btn-light' ?>" style="border-radius: 20px;">Selesai</a>
      <a href="<?= BASE_URL ?>admin/pesanan.php?status=dibatalkan" class="btn btn-sm <?= ($status == 'dibatalkan') ? 'btn-primary' : 'btn-light' ?>" style="border-radius: 20px;">Dibatalkan</a>
    </div>

    <div class="card" style="padding: 0; overflow: hidden;">
      <div class="table-responsive">
        <table class="table">
          <thead>
            <tr>
              <th>Kode Pesanan</th>
              <th>Tanggal</th>
              <th>Penerima</th>
              <th>No. WhatsApp</th>
              <th>Total Bayar</th>
              <th>Status</th>
              <th style="text-align: center; width: 120px;">Aksi</th>
            </tr>
          </thead>
          <tbody>
            <?php if ($result && mysqli_num_rows($result) > 0): ?>
              <?php while ($row = mysqli_fetch_assoc($result)): 
                // Format no hp untuk wa
                $wa_phone = preg_replace('/^0/', '62', preg_replace('/[^\d]/', '', $row['no_hp_penerima']));
              ?>
                <tr>
                  <td>
                    <strong style="color: var(--primary-blue);"><?= htmlspecialchars($row['kode_pesanan']) ?></strong>
                  </td>
                  <td style="font-size: 13px; color: var(--navy-light);">
                    <?= date('d/m/Y H:i', strtotime($row['tanggal_pesanan'])) ?>
                  </td>
                  <td>
                    <strong style="color: var(--navy);"><?= htmlspecialchars($row['nama_penerima']) ?></strong>
                  </td>
                  <td>
                    <a href="https://wa.me/<?= $wa_phone ?>" target="_blank" style="color: #16A34A; font-weight: 600;">
                      <i class="fa-brands fa-whatsapp"></i> <?= htmlspecialchars($row['no_hp_penerima']) ?>
                    </a>
                  </td>
                  <td style="font-weight: 800; color: var(--primary-blue);"><?= rupiah($row['total_bayar']) ?></td>
                  <td><?= badge_status_admin($row['status_pesanan']) ?></td>
                  <td style="text-align: center;">
                    <a href="<?= BASE_URL ?>admin/pesanan_detail.php?id=<?= $row['id_pesanan'] ?>" class="btn btn-sm btn-primary" title="Detail Pesanan">
                      <i class="fa-solid fa-file-invoice"></i> Detail
                    </a>
                  </td>
                </tr>
              <?php endwhile; ?>
            <?php else: ?>
              <tr>
                <td colspan="7" style="text-align: center; padding: 40px; color: var(--navy-light);">Tidak ada data pesanan pada kriteria ini.</td>
              </tr>
            <?php endif; ?>
          </tbody>
        </table>
      </div>
    </div>

<?php require_once __DIR__ . '/includes/footer.php'; ?>
