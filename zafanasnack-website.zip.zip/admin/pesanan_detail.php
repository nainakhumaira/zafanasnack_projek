<?php
$admin_page_title = "Rincian Pesanan";
require_once __DIR__ . '/includes/header.php';
require_once __DIR__ . '/includes/sidebar.php';

$id_pesanan = (int)($_GET['id'] ?? 0);

// UPDATE STATUS PESANAN
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['action']) && $_POST['action'] === 'update_status') {
    $status_baru = $_POST['status_pesanan'] ?? '';
    $allowed_status = ['menunggu_pembayaran', 'diproses', 'dikirim', 'selesai', 'dibatalkan'];

    if (in_array($status_baru, $allowed_status)) {
        $stmt_up = mysqli_prepare($koneksi, "UPDATE pesanan SET status_pesanan = ? WHERE id_pesanan = ?");
        mysqli_stmt_bind_param($stmt_up, "si", $status_baru, $id_pesanan);
        mysqli_stmt_execute($stmt_up);
        set_flash('success', 'Status pesanan berhasil diperbarui menjadi: ' . strtoupper($status_baru));
    }
    header("Location: " . BASE_URL . "admin/pesanan_detail.php?id=" . $id_pesanan);
    exit;
}

// AMBIL DATA PESANAN
$stmt = mysqli_prepare($koneksi, "SELECT p.*, u.nama_lengkap as nama_user, u.email as email_user 
                                  FROM pesanan p 
                                  JOIN users u ON p.id_user = u.id_user 
                                  WHERE p.id_pesanan = ?");
mysqli_stmt_bind_param($stmt, "i", $id_pesanan);
mysqli_stmt_execute($stmt);
$pesanan = mysqli_fetch_assoc(mysqli_stmt_get_result($stmt));

if (!$pesanan) {
    header("Location: " . BASE_URL . "admin/pesanan.php");
    exit;
}

// AMBIL DETAIL PRODUK
$stmt_items = mysqli_prepare($koneksi, "SELECT d.*, p.nama_produk, p.foto 
                                        FROM detail_pesanan d 
                                        JOIN produk p ON d.id_produk = p.id_produk 
                                        WHERE d.id_pesanan = ?");
mysqli_stmt_bind_param($stmt_items, "i", $id_pesanan);
mysqli_stmt_execute($stmt_items);
$items = mysqli_stmt_get_result($stmt_items);

$wa_phone = preg_replace('/^0/', '62', preg_replace('/[^\d]/', '', $pesanan['no_hp_penerima']));
$wa_msg = urlencode("Halo Kak " . $pesanan['nama_penerima'] . ", kami dari Admin ZAFANA SNACK ingin mengonfirmasi terkait pesanan nomor *" . $pesanan['kode_pesanan'] . "*.");
?>

<main class="admin-main">
  <div class="admin-topbar">
    <div>
      <h2 style="font-size: 20px; font-weight: 800; color: var(--navy);">Nota Pesanan: <?= htmlspecialchars($pesanan['kode_pesanan']) ?></h2>
      <p style="font-size: 13px; color: var(--navy-light);">Waktu transaksi: <?= date('d F Y, H:i', strtotime($pesanan['tanggal_pesanan'])) ?> WIB</p>
    </div>
    <div style="display: flex; gap: 8px;">
      <button onclick="window.print()" class="btn btn-sm btn-outline btn-no-print">
        <i class="fa-solid fa-print"></i> Cetak Nota
      </button>
      <a href="<?= BASE_URL ?>admin/pesanan.php" class="btn btn-sm btn-light btn-no-print">
        <i class="fa-solid fa-arrow-left"></i> Kembali
      </a>
    </div>
  </div>

  <div class="admin-body">
    <?= get_flash() ?>

    <div style="display: grid; grid-template-columns: 2fr 1fr; gap: 25px; align-items: start;">
      
      <!-- Kolom Kiri: Rincian Produk & Pengiriman -->
      <div>
        <div class="card" style="padding: 0; overflow: hidden; margin-bottom: 25px;">
          <div class="card-header" style="padding: 16px 20px; margin-bottom: 0;">
            <h3>Item Camilan yang Dipesan</h3>
          </div>
          <div class="table-responsive">
            <table class="table">
              <thead>
                <tr>
                  <th style="width: 50px;">Foto</th>
                  <th>Produk</th>
                  <th>Harga Satuan</th>
                  <th style="text-align: center;">Qty</th>
                  <th style="text-align: right;">Subtotal</th>
                </tr>
              </thead>
              <tbody>
                <?php while ($it = mysqli_fetch_assoc($items)): ?>
                  <tr>
                    <td>
                      <img src="<?= get_product_image_url($it['foto'] ?? '') ?>" 
                           style="width: 44px; height: 44px; object-fit: cover; border-radius: 6px; border: 1px solid var(--border-color); background: var(--bg-soft);"
                           loading="lazy"
                           onerror="this.onerror=null; this.src='<?= BASE_URL ?>assets/images/products/default_snack.jpg';">
                    </td>
                    <td><strong><?= htmlspecialchars($it['nama_produk']) ?></strong></td>
                    <td><?= rupiah($it['harga_satuan']) ?></td>
                    <td style="text-align: center; font-weight: 700;"><?= $it['jumlah'] ?></td>
                    <td style="text-align: right; font-weight: 700; color: var(--primary-blue);"><?= rupiah($it['subtotal']) ?></td>
                  </tr>
                <?php endwhile; ?>
              </tbody>
              <tfoot>
                <tr>
                  <td colspan="4" style="text-align: right; font-weight: 600;">Total Produk:</td>
                  <td style="text-align: right; font-weight: 700;"><?= rupiah($pesanan['total_produk']) ?></td>
                </tr>
                <tr>
                  <td colspan="4" style="text-align: right; font-weight: 600;">Ongkos Kirim:</td>
                  <td style="text-align: right; font-weight: 700;"><?= rupiah($pesanan['ongkir']) ?></td>
                </tr>
                <tr style="background: var(--light-blue);">
                  <td colspan="4" style="text-align: right; font-weight: 800; font-size: 15px; color: var(--primary-blue);">TOTAL BAYAR:</td>
                  <td style="text-align: right; font-weight: 800; font-size: 17px; color: var(--primary-blue);"><?= rupiah($pesanan['total_bayar']) ?></td>
                </tr>
              </tfoot>
            </table>
          </div>
        </div>

        <!-- Alamat Kirim -->
        <div class="card">
          <div class="card-header">
            <h3><i class="fa-solid fa-truck" style="color: var(--primary-blue);"></i> Data Pengiriman & Penerima</h3>
          </div>
          <div style="display: grid; grid-template-columns: 1fr 1fr; gap: 20px; font-size: 14px;">
            <div>
              <div style="color: var(--navy-light); margin-bottom: 4px;">Nama Penerima:</div>
              <strong style="color: var(--navy); font-size: 15px;"><?= htmlspecialchars($pesanan['nama_penerima']) ?></strong>
              <div style="margin-top: 10px; color: var(--navy-light); margin-bottom: 4px;">Nomor Telepon / WhatsApp:</div>
              <a href="https://wa.me/<?= $wa_phone ?>?text=<?= $wa_msg ?>" target="_blank" style="color: #16A34A; font-weight: 700;">
                <i class="fa-brands fa-whatsapp"></i> <?= htmlspecialchars($pesanan['no_hp_penerima']) ?>
              </a>
            </div>
            <div>
              <div style="color: var(--navy-light); margin-bottom: 4px;">Alamat Tujuan:</div>
              <p style="color: var(--navy); line-height: 1.5;"><?= nl2br(htmlspecialchars($pesanan['alamat_kirim'])) ?></p>
              <?php if (!empty($pesanan['catatan'])): ?>
                <div style="margin-top: 10px; padding: 10px; background: var(--bg-soft); border-radius: 6px; border: 1px dashed var(--border-color); font-size: 13px;">
                  <strong>Catatan Pembeli:</strong> "<?= htmlspecialchars($pesanan['catatan']) ?>"
                </div>
              <?php endif; ?>
            </div>
          </div>
        </div>
      </div>

      <!-- Kolom Kanan: Update Status & Pembayaran -->
      <div>
        <div class="card">
          <div class="card-header">
            <h3>Status Pesanan</h3>
          </div>

          <form action="<?= BASE_URL ?>admin/pesanan_detail.php?id=<?= $id_pesanan ?>" method="POST">
            <input type="hidden" name="action" value="update_status">
            
            <div class="form-group">
              <label class="form-label">Ubah Status:</label>
              <select name="status_pesanan" class="form-control" style="font-weight: 700; color: var(--primary-blue);">
                <option value="menunggu_pembayaran" <?= ($pesanan['status_pesanan'] === 'menunggu_pembayaran') ? 'selected' : '' ?>>Menunggu Pembayaran</option>
                <option value="diproses" <?= ($pesanan['status_pesanan'] === 'diproses') ? 'selected' : '' ?>>Diproses (Packing Snack)</option>
                <option value="dikirim" <?= ($pesanan['status_pesanan'] === 'dikirim') ? 'selected' : '' ?>>Sedang Dikirim (Kurir)</option>
                <option value="selesai" <?= ($pesanan['status_pesanan'] === 'selesai') ? 'selected' : '' ?>>Selesai (Sampai di Pembeli)</option>
                <option value="dibatalkan" <?= ($pesanan['status_pesanan'] === 'dibatalkan') ? 'selected' : '' ?>>Dibatalkan</option>
              </select>
            </div>

            <button type="submit" class="btn btn-primary btn-block btn-no-print">
              <i class="fa-solid fa-arrows-rotate"></i> Update Status
            </button>
          </form>

          <div style="margin-top: 25px; padding-top: 20px; border-top: 1px solid var(--border-color);">
            <div style="font-size: 13px; color: var(--navy-light); margin-bottom: 6px;">Metode Pembayaran:</div>
            <strong style="color: var(--navy);"><?= htmlspecialchars($pesanan['metode_pembayaran']) ?></strong>
          </div>

          <div style="margin-top: 20px;">
            <a href="https://wa.me/<?= $wa_phone ?>?text=<?= $wa_msg ?>" target="_blank" class="btn btn-outline btn-block btn-no-print" style="border-color: #25D366; color: #16A34A !important;">
              <i class="fa-brands fa-whatsapp"></i> Hubungi Pembeli via WA
            </a>
          </div>
        </div>
      </div>

    </div>

<?php require_once __DIR__ . '/includes/footer.php'; ?>
