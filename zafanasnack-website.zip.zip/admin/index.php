<?php
$admin_page_title = "Dashboard Utama Administrator";
require_once __DIR__ . '/includes/header.php';
require_once __DIR__ . '/includes/sidebar.php';

// 1. Total Pendapatan Valid
$q_omset = mysqli_query($koneksi, "SELECT SUM(total_bayar) as total FROM pesanan WHERE status_pesanan IN ('diproses', 'dikirim', 'selesai')");
$d_omset = mysqli_fetch_assoc($q_omset);
$total_omset = $d_omset['total'] ?? 0;

// 2. Total Transaksi Pesanan
$q_pesanan = mysqli_query($koneksi, "SELECT COUNT(*) as total FROM pesanan");
$d_pesanan = mysqli_fetch_assoc($q_pesanan);
$total_pesanan = $d_pesanan['total'] ?? 0;

// 3. Total Produk Aktif
$q_produk = mysqli_query($koneksi, "SELECT COUNT(*) as total FROM produk WHERE status = 'aktif'");
$d_produk = mysqli_fetch_assoc($q_produk);
$total_produk = $d_produk['total'] ?? 0;

// 4. Total Pelanggan Terdaftar
$q_pelanggan = mysqli_query($koneksi, "SELECT COUNT(*) as total FROM users WHERE role = 'pelanggan'");
$d_pelanggan = mysqli_fetch_assoc($q_pelanggan);
$total_pelanggan = $d_pelanggan['total'] ?? 0;

// 5. Query 7 Hari Terakhir untuk Grafik Penjualan
$chart_labels = [];
$chart_values = [];

for ($i = 6; $i >= 0; $i--) {
    $tgl = date('Y-m-d', strtotime("-$i days"));
    $label = date('d M', strtotime($tgl));
    
    $q_day = mysqli_query($koneksi, "SELECT SUM(total_bayar) as omset 
                                    FROM pesanan 
                                    WHERE DATE(tanggal_pesanan) = '$tgl' 
                                    AND status_pesanan IN ('diproses', 'dikirim', 'selesai')");
    $d_day = mysqli_fetch_assoc($q_day);
    $omset_hari = (int)($d_day['omset'] ?? 0);

    $chart_labels[] = $label;
    $chart_values[] = $omset_hari;
}

// 6. Produk Stok Menipis (< 10)
$q_stok_kritis = mysqli_query($koneksi, "SELECT * FROM produk WHERE stok < 10 ORDER BY stok ASC LIMIT 5");

// 7. Pesanan Terbaru
$q_pesanan_baru = mysqli_query($koneksi, "SELECT p.*, u.nama_lengkap 
                                         FROM pesanan p 
                                         JOIN users u ON p.id_user = u.id_user 
                                         ORDER BY p.id_pesanan DESC LIMIT 5");
?>

<main class="admin-main">
  <div class="admin-topbar">
    <div>
      <h2 style="font-size: 20px; font-weight: 800; color: var(--navy); margin-bottom: 2px;">Dashboard Administrator</h2>
      <p style="font-size: 13px; color: var(--navy-light); margin: 0;">
        Halo, <strong><?= htmlspecialchars($admin_user['nama_lengkap']) ?></strong>! Pantau performa bisnis ZAFANA SNACK hari ini.
      </p>
    </div>
    <div style="font-size: 13px; color: var(--navy-light); display: flex; align-items: center; gap: 8px;">
      <i class="fa-regular fa-calendar text-blue"></i> <?= date('d F Y') ?>
    </div>
  </div>

  <div class="admin-body">
    <?= get_flash() ?>

    <!-- Identitas Resmi Toko ZAFANA SNACK -->
    <div style="background: linear-gradient(135deg, #1E293B 0%, #0F172A 100%); color: #fff; padding: 18px 24px; border-radius: var(--radius-md); margin-bottom: 24px; display: flex; justify-content: space-between; align-items: center; flex-wrap: wrap; gap: 15px; box-shadow: var(--shadow-sm);">
      <div style="display: flex; align-items: center; gap: 15px;">
        <div style="width: 44px; height: 44px; border-radius: 10px; background: rgba(37, 99, 235, 0.2); border: 1px solid rgba(96, 165, 250, 0.3); display: flex; align-items: center; justify-content: center; font-size: 20px; color: #60A5FA;">
          <i class="fa-solid fa-store"></i>
        </div>
        <div>
          <div style="display: flex; align-items: center; gap: 10px; flex-wrap: wrap;">
            <strong style="font-size: 16px; color: #fff;"><?= STORE_NAME ?></strong>
            <span style="font-size: 12px; background: rgba(37, 99, 235, 0.25); color: #93C5FD; padding: 2px 8px; border-radius: 20px; font-weight: 600;">"<?= STORE_SLOGAN ?>"</span>
          </div>
          <div style="font-size: 13px; color: #94A3B8; margin-top: 4px; display: flex; gap: 16px; flex-wrap: wrap;">
            <span><i class="fa-solid fa-location-dot" style="color: #60A5FA;"></i> <?= STORE_ADDRESS ?></span>
            <span><i class="fa-solid fa-phone" style="color: #34D399;"></i> <?= STORE_PHONE ?></span>
            <span><i class="fa-brands fa-whatsapp" style="color: #22C55E;"></i> +<?= WA_STORE_NUMBER ?></span>
          </div>
        </div>
      </div>
      <a href="<?= BASE_URL ?>" target="_blank" class="btn btn-sm btn-outline" style="border-color: #475569; color: #E2E8F0;">
        <i class="fa-solid fa-arrow-up-right-from-square"></i> Kunjungi Toko
      </a>
    </div>

    <!-- STATISTIK KARTU UTAMA -->
    <div class="stat-grid">
      <div class="stat-card">
        <div class="stat-icon green">
          <i class="fa-solid fa-coins"></i>
        </div>
        <div class="stat-info">
          <h3><?= rupiah($total_omset) ?></h3>
          <p>Total Omset Penjualan</p>
        </div>
      </div>

      <div class="stat-card">
        <div class="stat-icon blue">
          <i class="fa-solid fa-cart-shopping"></i>
        </div>
        <div class="stat-info">
          <h3><?= number_format($total_pesanan) ?></h3>
          <p>Total Pesanan Masuk</p>
        </div>
      </div>

      <div class="stat-card">
        <div class="stat-icon orange">
          <i class="fa-solid fa-cookie-bite"></i>
        </div>
        <div class="stat-info">
          <h3><?= number_format($total_produk) ?></h3>
          <p>Varian Snack Aktif</p>
        </div>
      </div>

      <div class="stat-card">
        <div class="stat-icon red">
          <i class="fa-solid fa-users"></i>
        </div>
        <div class="stat-info">
          <h3><?= number_format($total_pelanggan) ?></h3>
          <p>Pelanggan Terdaftar</p>
        </div>
      </div>
    </div>

    <!-- GRAFIK PENJUALAN MENGGUNAKAN CHART.JS -->
    <div class="card" style="margin-bottom: 25px;">
      <div class="card-header">
        <h3><i class="fa-solid fa-chart-line text-blue"></i> Tren Penjualan 7 Hari Terakhir</h3>
        <span style="font-size: 12px; color: var(--navy-light);">Update Real-time dari Transaksi</span>
      </div>
      <div style="height: 280px; position: relative;">
        <canvas id="salesChart"></canvas>
      </div>
    </div>

    <!-- DUA KOLOM: PESANAN TERBARU & PERINGATAN STOK -->
    <div class="admin-two-cols">
      
      <!-- Tabel Pesanan Terbaru -->
      <div class="card" style="padding: 0; overflow: hidden;">
        <div class="card-header" style="padding: 16px 20px; margin-bottom: 0;">
          <h3><i class="fa-solid fa-clock-rotate-left text-blue"></i> 5 Pesanan Terbaru</h3>
          <a href="<?= BASE_URL ?>admin/pesanan.php" class="btn btn-sm btn-light">Lihat Semua</a>
        </div>

        <div class="table-responsive">
          <table class="table">
            <thead>
              <tr>
                <th>Kode</th>
                <th>Penerima</th>
                <th>Total</th>
                <th>Status</th>
                <th style="text-align: center;">Aksi</th>
              </tr>
            </thead>
            <tbody>
              <?php if ($q_pesanan_baru && mysqli_num_rows($q_pesanan_baru) > 0): ?>
                <?php while ($pb = mysqli_fetch_assoc($q_pesanan_baru)): ?>
                  <tr>
                    <td><strong><?= htmlspecialchars($pb['kode_pesanan']) ?></strong></td>
                    <td><?= htmlspecialchars($pb['nama_penerima']) ?></td>
                    <td style="font-weight: 700; color: var(--primary-blue);"><?= rupiah($pb['total_bayar']) ?></td>
                    <td>
                      <span style="font-size: 11px; font-weight: 700; padding: 3px 8px; border-radius: 12px; background: #DBEAFE; color: #1E40AF;">
                        <?= htmlspecialchars($pb['status_pesanan']) ?>
                      </span>
                    </td>
                    <td style="text-align: center;">
                      <a href="<?= BASE_URL ?>admin/pesanan_detail.php?id=<?= $pb['id_pesanan'] ?>" class="btn btn-sm btn-light" title="Buka Detail">
                        <i class="fa-solid fa-eye"></i>
                      </a>
                    </td>
                  </tr>
                <?php endwhile; ?>
              <?php else: ?>
                <tr>
                  <td colspan="5" style="text-align: center; color: var(--navy-light); padding: 30px;">Belum ada pesanan masuk.</td>
                </tr>
              <?php endif; ?>
            </tbody>
          </table>
        </div>
      </div>

      <!-- Peringatan Stok Menipis -->
      <div class="card">
        <div class="card-header">
          <h3><i class="fa-solid fa-triangle-exclamation" style="color: #F59E0B;"></i> Stok Menipis (&lt; 10)</h3>
        </div>

        <?php if ($q_stok_kritis && mysqli_num_rows($q_stok_kritis) > 0): ?>
          <ul style="list-style: none;">
            <?php while ($sk = mysqli_fetch_assoc($q_stok_kritis)): ?>
              <li style="display: flex; justify-content: space-between; align-items: center; padding: 10px 0; border-bottom: 1px solid var(--border-color);">
                <div>
                  <strong style="color: var(--navy);"><?= htmlspecialchars($sk['nama_produk']) ?></strong>
                  <div style="font-size: 12px; color: var(--navy-light);"><?= rupiah($sk['harga']) ?></div>
                </div>
                <div>
                  <span style="background: #FEE2E2; color: #DC2626; font-weight: 800; font-size: 12px; padding: 3px 8px; border-radius: 6px;">
                    Sisa: <?= $sk['stok'] ?>
                  </span>
                </div>
              </li>
            <?php endwhile; ?>
          </ul>
          <a href="<?= BASE_URL ?>admin/stok.php" class="btn btn-block btn-sm btn-outline" style="margin-top: 15px;">
            <i class="fa-solid fa-boxes-stacked"></i> Update Stok Sekarang
          </a>
        <?php else: ?>
          <div style="text-align: center; padding: 25px 10px; color: #10B981;">
            <i class="fa-solid fa-circle-check" style="font-size: 32px; margin-bottom: 8px;"></i>
            <p style="font-size: 13px;">Semua stok produk saat ini aman!</p>
          </div>
        <?php endif; ?>
      </div>

    </div>

    <!-- Script Chart.js Inisialisasi -->
    <script>
      document.addEventListener('DOMContentLoaded', function () {
        const ctx = document.getElementById('salesChart');
        if (!ctx) return;

        const labels = <?= json_encode($chart_labels) ?>;
        const dataValues = <?= json_encode($chart_values) ?>;

        new Chart(ctx, {
          type: 'line',
          data: {
            labels: labels,
            datasets: [{
              label: 'Total Penjualan (Rp)',
              data: dataValues,
              borderColor: '#2563EB',
              backgroundColor: 'rgba(37, 99, 235, 0.1)',
              borderWidth: 3,
              fill: true,
              tension: 0.35,
              pointBackgroundColor: '#2563EB',
              pointRadius: 5,
              pointHoverRadius: 7
            }]
          },
          options: {
            responsive: true,
            maintainAspectRatio: false,
            plugins: {
              legend: {
                display: false
              },
              tooltip: {
                callbacks: {
                  label: function (context) {
                    return ' Omset: Rp ' + context.parsed.y.toLocaleString('id-ID');
                  }
                }
              }
            },
            scales: {
              y: {
                beginAtZero: true,
                grid: {
                  color: '#F1F5F9'
                },
                ticks: {
                  callback: function (value) {
                    return 'Rp ' + (value / 1000) + 'k';
                  }
                }
              },
              x: {
                grid: {
                  display: false
                }
              }
            }
          }
        });
      });
    </script>

<?php require_once __DIR__ . '/includes/footer.php'; ?>
