<?php
$admin_page_title = "Edit Produk Camilan";
require_once __DIR__ . '/includes/header.php';
require_once __DIR__ . '/includes/sidebar.php';

$id_produk = (int)($_GET['id'] ?? 0);
$stmt = mysqli_prepare($koneksi, "SELECT * FROM produk WHERE id_produk = ?");
mysqli_stmt_bind_param($stmt, "i", $id_produk);
mysqli_stmt_execute($stmt);
$produk = mysqli_fetch_assoc(mysqli_stmt_get_result($stmt));

if (!$produk) {
    header("Location: " . BASE_URL . "admin/produk.php");
    exit;
}

$error = '';
$kategori_list = mysqli_query($koneksi, "SELECT * FROM kategori ORDER BY CASE WHEN slug = 'original-gurih' THEN 1 WHEN slug = 'peyek-kacang' THEN 2 WHEN slug = 'peyek-udang' THEN 3 WHEN slug = 'peyek-kacang-kedelai' THEN 4 ELSE 5 END, nama_kategori ASC");

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $id_kategori = (int)($_POST['id_kategori'] ?? 0);
    $nama_produk = trim($_POST['nama_produk'] ?? '');
    $deskripsi = trim($_POST['deskripsi'] ?? '');
    $harga = (int)($_POST['harga'] ?? 0);
    $harga_coret = (int)($_POST['harga_coret'] ?? 0);
    $berat_gram = (int)($_POST['berat_gram'] ?? 150);
    $stok = (int)($_POST['stok'] ?? 0);
    $status = $_POST['status'] ?? 'aktif';
    $is_best_seller = isset($_POST['is_best_seller']) ? 1 : 0;
    $is_promo = isset($_POST['is_promo']) ? 1 : 0;

    if (empty($nama_produk) || $id_kategori <= 0 || $harga <= 0) {
        $error = 'Nama snack, kategori, dan harga jual wajib diisi!';
    } else {
        $foto_name = !empty($produk['foto']) ? $produk['foto'] : 'default_snack.jpg';
        $upload_error = null;

        // Cek jika ada upload foto baru dari komputer
        if (isset($_FILES['foto']) && $_FILES['foto']['error'] !== UPLOAD_ERR_NO_FILE) {
            $uploaded_file = handle_product_image_upload($_FILES['foto'], $upload_error);
            if ($uploaded_file === false) {
                $error = $upload_error ?? 'Gagal mengunggah foto baru.';
            } else if ($uploaded_file !== null) {
                $foto_name = $uploaded_file;
            }
        }

        if (empty($error)) {
            $stmt_update = mysqli_prepare($koneksi, "UPDATE produk SET id_kategori = ?, nama_produk = ?, deskripsi = ?, harga = ?, harga_coret = ?, berat_gram = ?, stok = ?, foto = ?, is_best_seller = ?, is_promo = ?, status = ? WHERE id_produk = ?");
            mysqli_stmt_bind_param($stmt_update, "issiiiisiisi", $id_kategori, $nama_produk, $deskripsi, $harga, $harga_coret, $berat_gram, $stok, $foto_name, $is_best_seller, $is_promo, $status, $id_produk);

            if (mysqli_stmt_execute($stmt_update)) {
                set_flash('success', 'Data camilan "' . htmlspecialchars($nama_produk) . '" berhasil diperbarui!');
                header("Location: " . BASE_URL . "admin/produk.php");
                exit;
            } else {
                $error = 'Gagal memperbarui produk. Silakan coba kembali.';
            }
        }
    }
}
?>

<main class="admin-main">
  <div class="admin-topbar">
    <div>
      <h2 style="font-size: 20px; font-weight: 800; color: var(--navy);">Edit Produk Camilan</h2>
      <p style="font-size: 13px; color: var(--navy-light);">Perbarui rincian, harga diskon, stok, atau foto produk</p>
    </div>
    <a href="<?= BASE_URL ?>admin/produk.php" class="btn btn-sm btn-outline">
      <i class="fa-solid fa-arrow-left"></i> Kembali ke Daftar
    </a>
  </div>

  <div class="admin-body">
    <?php if (!empty($error)): ?>
      <div class="alert alert-danger"><?= htmlspecialchars($error) ?></div>
    <?php endif; ?>

    <div class="card" style="max-width: 800px;">
      <form action="<?= BASE_URL ?>admin/produk_edit.php?id=<?= $id_produk ?>" method="POST" enctype="multipart/form-data">
        <div class="form-group">
          <label class="form-label">Nama Camilan / Snack *</label>
          <input type="text" name="nama_produk" class="form-control" value="<?= htmlspecialchars($_POST['nama_produk'] ?? $produk['nama_produk']) ?>" required>
        </div>

        <div style="display: grid; grid-template-columns: 1fr 1fr; gap: 20px;">
          <div class="form-group">
            <label class="form-label">Kategori *</label>
            <select name="id_kategori" class="form-control" required>
              <?php while ($k = mysqli_fetch_assoc($kategori_list)): ?>
                <option value="<?= $k['id_kategori'] ?>" <?= ($produk['id_kategori'] == $k['id_kategori']) ? 'selected' : '' ?>>
                  <?= htmlspecialchars($k['nama_kategori']) ?>
                </option>
              <?php endwhile; ?>
            </select>
          </div>

          <div class="form-group">
            <label class="form-label">Harga Jual (Rp) *</label>
            <input type="number" name="harga" class="form-control" value="<?= (int)($_POST['harga'] ?? $produk['harga']) ?>" required>
          </div>
        </div>

        <div style="display: grid; grid-template-columns: 1fr 1fr 1fr; gap: 20px;">
          <div class="form-group">
            <label class="form-label">Harga Coret / Asli</label>
            <input type="number" name="harga_coret" class="form-control" value="<?= (int)($_POST['harga_coret'] ?? $produk['harga_coret']) ?>">
            <small style="color: var(--navy-light); font-size: 11px;">Kosongkan jika tidak sedang diskon</small>
          </div>

          <div class="form-group">
            <label class="form-label">Berat Bersih (gram)</label>
            <input type="number" name="berat_gram" class="form-control" value="<?= (int)($_POST['berat_gram'] ?? $produk['berat_gram']) ?>">
          </div>

          <div class="form-group">
            <label class="form-label">Jumlah Stok</label>
            <input type="number" name="stok" class="form-control" value="<?= (int)($_POST['stok'] ?? $produk['stok']) ?>" min="0">
          </div>
        </div>

        <div style="display: grid; grid-template-columns: 1fr 1fr; gap: 20px; margin-bottom: 15px;">
          <div class="form-group">
            <label class="form-label">Status Produk</label>
            <select name="status" class="form-control">
              <option value="aktif" <?= ($produk['status'] === 'aktif') ? 'selected' : '' ?>>Aktif (Tampil)</option>
              <option value="nonaktif" <?= ($produk['status'] === 'nonaktif') ? 'selected' : '' ?>>Nonaktif (Sembunyikan)</option>
            </select>
          </div>

          <div style="display: flex; gap: 20px; align-items: center; padding-top: 25px;">
            <label style="display: flex; align-items: center; gap: 8px; font-weight: 600; cursor: pointer;">
              <input type="checkbox" name="is_best_seller" value="1" <?= (!empty($produk['is_best_seller'])) ? 'checked' : '' ?>> Best Seller 🔥
            </label>
            <label style="display: flex; align-items: center; gap: 8px; font-weight: 600; cursor: pointer;">
              <input type="checkbox" name="is_promo" value="1" <?= (!empty($produk['is_promo'])) ? 'checked' : '' ?>> Promo Diskon ⚡
            </label>
          </div>
        </div>

        <div class="form-group">
          <label class="form-label">Deskripsi Lengkap</label>
          <textarea name="deskripsi" class="form-control" rows="4"><?= htmlspecialchars($_POST['deskripsi'] ?? $produk['deskripsi']) ?></textarea>
        </div>

        <div class="form-group">
          <label class="form-label" style="font-weight: 700; color: var(--navy);">
            <i class="fa-solid fa-image text-blue"></i> Foto Produk Saat Ini
          </label>
          <div style="display: flex; align-items: center; gap: 15px; margin-bottom: 15px; padding: 12px; background: #fff; border-radius: var(--radius-sm); border: 1px solid var(--border-color);">
            <div style="width: 80px; height: 80px; border-radius: 8px; overflow: hidden; border: 1px solid var(--border-color); background: var(--soft-gray); display: flex; align-items: center; justify-content: center; flex-shrink: 0;">
              <img id="currentFoto" src="<?= get_product_image_url($produk['foto'] ?? '') ?>" 
                   style="max-width: 100%; max-height: 100%; object-fit: contain;"
                   loading="lazy"
                   onerror="this.onerror=null; this.src='<?= BASE_URL ?>assets/images/products/default_snack.jpg';">
            </div>
            <div>
              <span style="font-size: 11px; background: var(--light-blue); color: var(--primary-blue); padding: 2px 8px; border-radius: 12px; font-weight: 700;">Foto Aktif</span>
              <strong style="color: var(--navy); display: block; font-size: 13px; margin-top: 4px;"><?= htmlspecialchars($produk['foto']) ?></strong>
              <small style="color: var(--navy-light);">Foto ini saat ini tampil di Beranda, Katalog, dan Detail Produk.</small>
            </div>
          </div>

          <label class="form-label" style="font-weight: 700; color: var(--navy); margin-top: 15px;">
            <i class="fa-solid fa-camera text-blue"></i> Ganti Foto Produk dari Komputer (Opsional)
          </label>
          <div style="background: var(--soft-gray); border: 2px dashed #93C5FD; border-radius: var(--radius-md); padding: 16px; text-align: center; position: relative;">
            <input type="file" name="foto" class="form-control" accept=".jpg,.jpeg,.png,.webp,image/jpeg,image/png,image/webp" id="editFotoInput" style="cursor: pointer;">
            <div style="margin-top: 6px; font-size: 12px; color: var(--navy-light);">
              <i class="fa-solid fa-circle-info text-blue"></i> Mendukung: <strong>JPG, JPEG, PNG, WEBP</strong> (Maksimal 5 MB). Biarkan kosong jika tidak ingin mengganti foto.
            </div>
          </div>

          <!-- Box Live Preview Gambar Baru -->
          <div id="newFotoPreviewBox" style="margin-top: 15px; display: none; padding: 15px; background: #ECFDF5; border-radius: var(--radius-sm); border: 1px solid #A7F3D0; box-shadow: var(--shadow-sm);">
            <div style="font-size: 13px; font-weight: 700; color: #065F46; margin-bottom: 8px;">
              <i class="fa-solid fa-sparkles text-success"></i> Preview Foto Baru yang Akan Disimpan:
            </div>
            <div style="display: flex; align-items: center; gap: 16px; flex-wrap: wrap;">
              <div style="width: 100px; height: 100px; border-radius: 8px; overflow: hidden; border: 1px solid #A7F3D0; background: #fff; display: flex; align-items: center; justify-content: center;">
                <img id="newFotoPreview" src="" alt="Preview Foto Baru" style="max-width: 100%; max-height: 100%; object-fit: contain;">
              </div>
              <div>
                <div id="newPreviewFileName" style="font-weight: 700; color: #065F46; font-size: 13px;"></div>
                <div id="newPreviewFileSize" style="color: #047857; font-size: 12px; margin-top: 2px;"></div>
                <button type="button" id="btnBatalGantiFoto" class="btn btn-sm btn-outline" style="margin-top: 8px; color: #EF4444; border-color: #FCA5A5; background: #fff;">
                  <i class="fa-solid fa-xmark"></i> Batal Ganti Foto
                </button>
              </div>
            </div>
          </div>
        </div>

        <div style="margin-top: 25px; display: flex; gap: 12px;">
          <button type="submit" class="btn btn-primary btn-lg">
            <i class="fa-solid fa-floppy-disk"></i> Simpan Produk
          </button>
          <a href="<?= BASE_URL ?>admin/produk.php" class="btn btn-light btn-lg">Batal</a>
        </div>
      </form>
    </div>

    <script>
      const editFotoInput = document.getElementById('editFotoInput');
      const newFotoPreviewBox = document.getElementById('newFotoPreviewBox');
      const newFotoPreview = document.getElementById('newFotoPreview');
      const newPreviewFileName = document.getElementById('newPreviewFileName');
      const newPreviewFileSize = document.getElementById('newPreviewFileSize');
      const btnBatalGantiFoto = document.getElementById('btnBatalGantiFoto');

      if (editFotoInput) {
        editFotoInput.addEventListener('change', function () {
          const file = this.files[0];
          if (file) {
            // Validasi ukuran 5MB
            if (file.size > 5 * 1024 * 1024) {
              alert('Ukuran file melebihi batas maksimal 5 MB.');
              this.value = '';
              newFotoPreviewBox.style.display = 'none';
              return;
            }

            const reader = new FileReader();
            reader.onload = function (e) {
              newFotoPreview.src = e.target.result;
              newPreviewFileName.textContent = file.name;
              newPreviewFileSize.textContent = (file.size / 1024).toFixed(1) + ' KB (' + file.type + ')';
              newFotoPreviewBox.style.display = 'block';
            }
            reader.readAsDataURL(file);
          } else {
            newFotoPreviewBox.style.display = 'none';
          }
        });
      }

      if (btnBatalGantiFoto) {
        btnBatalGantiFoto.addEventListener('click', function () {
          editFotoInput.value = '';
          newFotoPreviewBox.style.display = 'none';
          newFotoPreview.src = '';
        });
      }
    </script>

<?php require_once __DIR__ . '/includes/footer.php'; ?>
