<?php
$admin_page_title = "Data Pelanggan";
require_once __DIR__ . '/includes/header.php';
require_once __DIR__ . '/includes/sidebar.php';

// Ambil data pelanggan beserta statistik belanja mereka
$query = "SELECT u.*, 
                 COUNT(p.id_pesanan) as total_pesanan,
                 COALESCE(SUM(CASE WHEN p.status_pesanan IN ('diproses', 'dikirim', 'selesai') THEN p.total_bayar ELSE 0 END), 0) as total_belanja
          FROM users u 
          LEFT JOIN pesanan p ON u.id_user = p.id_user 
          WHERE u.role = 'pelanggan'
          GROUP BY u.id_user 
          ORDER BY u.id_user DESC";
$result = mysqli_query($koneksi, $query);
?>

<main class="admin-main">
  <div class="admin-topbar">
    <div>
      <h2 style="font-size: 20px; font-weight: 800; color: var(--navy);">Data Pelanggan Terdaftar</h2>
      <p style="font-size: 13px; color: var(--navy-light);">Kelola kontak pembeli dan pantau riwayat loyalitas pelanggan</p>
    </div>
  </div>

  <div class="admin-body">
    <?= get_flash() ?>

    <div class="card" style="padding: 0; overflow: hidden;">
      <div class="card-header" style="padding: 16px 20px; margin-bottom: 0;">
        <h3>Daftar Member ZAFANA SNACK (<?= mysqli_num_rows($result) ?>)</h3>
      </div>

      <div class="table-responsive">
        <table class="table">
          <thead>
            <tr>
              <th style="width: 50px;">No</th>
              <th>Nama Lengkap</th>
              <th>Alamat Email</th>
              <th>Nomor WhatsApp</th>
              <th>Total Order</th>
              <th>Total Belanja</th>
              <th>Tgl Bergabung</th>
              <th style="text-align: center;">Aksi</th>
            </tr>
          </thead>
          <tbody>
            <?php if ($result && mysqli_num_rows($result) > 0): $no = 1; ?>
              <?php while ($c = mysqli_fetch_assoc($result)): 
                $wa_phone = preg_replace('/^0/', '62', preg_replace('/[^\d]/', '', $c['no_hp']));
              ?>
                <tr>
                  <td><?= $no++ ?></td>
                  <td><strong><?= htmlspecialchars($c['nama_lengkap']) ?></strong></td>
                  <td><?= htmlspecialchars($c['email']) ?></td>
                  <td>
                    <a href="https://wa.me/<?= $wa_phone ?>" target="_blank" style="color: #16A34A; font-weight: 600;">
                      <i class="fa-brands fa-whatsapp"></i> <?= htmlspecialchars($c['no_hp']) ?>
                    </a>
                  </td>
                  <td>
                    <span style="font-weight: 700; color: var(--navy);"><?= (int)$c['total_pesanan'] ?> kali</span>
                  </td>
                  <td style="font-weight: 800; color: var(--primary-blue);"><?= rupiah($c['total_belanja']) ?></td>
                  <td style="font-size: 13px; color: var(--navy-light);"><?= date('d/m/Y', strtotime($c['created_at'])) ?></td>
                  <td style="text-align: center;">
                    <a href="https://wa.me/<?= $wa_phone ?>?text=<?= urlencode('Halo Kak ' . $c['nama_lengkap'] . ', kami dari Zafana Snack...') ?>" target="_blank" class="btn btn-sm btn-outline" style="border-color: #25D366; color: #16A34A !important; padding: 4px 10px;">
                      <i class="fa-brands fa-whatsapp"></i> Chat
                    </a>
                  </td>
                </tr>
              <?php endwhile; ?>
            <?php else: ?>
              <tr>
                <td colspan="8" style="text-align: center; padding: 40px; color: var(--navy-light);">Belum ada pelanggan terdaftar.</td>
              </tr>
            <?php endif; ?>
          </tbody>
        </table>
      </div>
    </div>

<?php require_once __DIR__ . '/includes/footer.php'; ?>
