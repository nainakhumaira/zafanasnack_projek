<?php
require_once __DIR__ . '/../config/koneksi.php';

unset($_SESSION['user']);
header("Location: " . BASE_URL . "admin/login.php");
exit;
