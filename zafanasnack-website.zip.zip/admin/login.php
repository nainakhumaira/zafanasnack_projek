<?php
require_once __DIR__ . '/../config/koneksi.php';

// Jika sudah login sebagai admin, langsung lempar ke dashboard
if (is_admin()) {
    header("Location: " . BASE_URL . "admin/index.php");
    exit;
}

$error = '';

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $email = trim($_POST['email'] ?? '');
    $password = $_POST['password'] ?? '';

    if (empty($email) || empty($password)) {
        $error = 'Email dan password admin harus diisi!';
    } else {
        $stmt = mysqli_prepare($koneksi, "SELECT * FROM users WHERE email = ? AND role = 'admin' LIMIT 1");
        mysqli_stmt_bind_param($stmt, "s", $email);
        mysqli_stmt_execute($stmt);
        $admin = mysqli_fetch_assoc(mysqli_stmt_get_result($stmt));

        if ($admin && password_verify($password, $admin['password'])) {
            $_SESSION['user'] = [
                'id_user' => $admin['id_user'],
                'nama_lengkap' => $admin['nama_lengkap'],
                'email' => $admin['email'],
                'no_hp' => $admin['no_hp'],
                'role' => 'admin'
            ];
            header("Location: " . BASE_URL . "admin/index.php");
            exit;
        } else {
            $error = 'Akun admin tidak ditemukan atau sandi salah!';
        }
    }
}
?>
<!DOCTYPE html>
<html lang="id">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title>Login Administrator - ZAFANA SNACK</title>
  <link rel="preconnect" href="https://fonts.googleapis.com">
  <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
  <link href="https://fonts.googleapis.com/css2?family=Plus+Jakarta+Sans:wght@400;600;700;800&display=swap" rel="stylesheet">
  <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">
  <link rel="stylesheet" href="<?= BASE_URL ?>assets/css/style.css">
</head>
<body style="background-color: #0F172A; display: flex; align-items: center; justify-content: center; min-height: 100vh; padding: 20px;">

<div style="width: 100%; max-width: 420px; background: #FFFFFF; border-radius: 16px; padding: 35px 30px; box-shadow: 0 10px 30px rgba(0,0,0,0.3);">
  <div style="text-align: center; margin-bottom: 25px;">
    <div style="width: 60px; height: 60px; background-color: var(--light-blue); color: var(--primary-blue); border-radius: 50%; display: flex; align-items: center; justify-content: center; font-size: 26px; margin: 0 auto 12px;">
      <i class="fa-solid fa-user-shield"></i>
    </div>
    <h2 style="font-size: 22px; color: var(--navy); font-weight: 800;">Panel Administrator</h2>
    <p style="color: var(--navy-light); font-size: 13px;">Masuk untuk mengelola operasional ZAFANA SNACK</p>
  </div>

  <?php if (!empty($error)): ?>
    <div class="alert alert-danger" style="font-size: 13px;"><?= htmlspecialchars($error) ?></div>
  <?php endif; ?>

  <form action="<?= BASE_URL ?>admin/login.php" method="POST">
    <div class="form-group">
      <label class="form-label">Email Admin</label>
      <input type="email" name="email" class="form-control" placeholder="admin@zafanasnack.com" value="<?= htmlspecialchars($_POST['email'] ?? 'admin@zafanasnack.com') ?>" required>
    </div>

    <div class="form-group">
      <label class="form-label">Password</label>
      <input type="password" name="password" class="form-control" placeholder="••••••••" required>
    </div>

    <button type="submit" class="btn btn-primary btn-block btn-lg" style="margin-top: 10px;">
      <i class="fa-solid fa-lock-open"></i> Masuk Dashboard
    </button>
  </form>

  <div style="text-align: center; margin-top: 25px; padding-top: 20px; border-top: 1px solid var(--border-color); font-size: 13px;">
    <a href="<?= BASE_URL ?>" style="color: var(--navy-light); text-decoration: none;">
      <i class="fa-solid fa-arrow-left"></i> Kembali ke Toko Utama
    </a>
  </div>
</div>

</body>
</html>
