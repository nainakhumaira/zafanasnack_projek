<?php
$admin_page_title = "Kelola Produk Camilan";
require_once __DIR__ . '/includes/header.php';
require_once __DIR__ . '/includes/sidebar.php';

// TOGGLE STATUS PRODUK (AKTIF / NONAKTIF)
if (isset($_GET['action']) && $_GET['action'] === 'toggle_status') {
    $id_tog = (int)($_GET['id'] ?? 0);
    $q_cur = mysqli_query($koneksi, "SELECT status, nama_produk FROM produk WHERE id_produk = $id_tog");
    if ($row_cur = mysqli_fetch_assoc($q_cur)) {
        $new_st = ($row_cur['status'] === 'aktif') ? 'nonaktif' : 'aktif';
        mysqli_query($koneksi, "UPDATE produk SET status = '$new_st' WHERE id_produk = $id_tog");
        $status_label = ($new_st === 'aktif') ? 'DIAKTIFKAN (tampil di Beranda & Katalog)' : 'DINONAKTIFKAN (disembunyikan dari pengunjung)';
        set_flash('success', 'Status produk "' . htmlspecialchars($row_cur['nama_produk']) . '" berhasil ' . $status_label . '.');
    }
    header("Location: " . BASE_URL . "admin/produk.php");
    exit;
}

// HAPUS PRODUK
if (isset($_GET['action']) && $_GET['action'] === 'hapus') {
    $id_del = (int)($_GET['id'] ?? 0);
    // Cek apakah ada riwayat pesanan dengan produk ini
    $cek_order = mysqli_query($koneksi, "SELECT COUNT(*) as total FROM detail_pesanan WHERE id_produk = $id_del");
    $d_order = mysqli_fetch_assoc($cek_order);

    if ($d_order && $d_order['total'] > 0) {
        // Jangan hapus permanen agar tidak merusak relasi nota pesanan, melainkan nonaktifkan statusnya
        mysqli_query($koneksi, "UPDATE produk SET status = 'nonaktif' WHERE id_produk = $id_del");
        set_flash('warning', 'Produk ini memiliki riwayat transaksi pesanan, sehingga otomatis dinonaktifkan (tidak tampil di Beranda/Katalog) demi menjaga integritas nota pembeli.');
    } else {
        // Ambil info foto jika ada di folder uploads/produk/
        $q_foto = mysqli_query($koneksi, "SELECT foto FROM produk WHERE id_produk = $id_del");
        $d_foto = mysqli_fetch_assoc($q_foto);
        $foto_del = $d_foto['foto'] ?? '';

        mysqli_query($koneksi, "DELETE FROM produk WHERE id_produk = $id_del");

        if (!empty($foto_del) && $foto_del !== 'default_snack.jpg') {
            $up_path = dirname(__DIR__) . DIRECTORY_SEPARATOR . 'uploads' . DIRECTORY_SEPARATOR . 'produk' . DIRECTORY_SEPARATOR . $foto_del;
            if (file_exists($up_path)) {
                @unlink($up_path);
            }
        }
        set_flash('success', 'Produk berhasil dihapus permanen.');
    }
    header("Location: " . BASE_URL . "admin/produk.php");
    exit;
}

// FILTER & QUERY
$cari = trim($_GET['cari'] ?? '');
$sql = "SELECT p.*, k.nama_kategori 
        FROM produk p 
        JOIN kategori k ON p.id_kategori = k.id_kategori";

if (!empty($cari)) {
    $sql .= " WHERE p.nama_produk LIKE '%" . mysqli_real_escape_string($koneksi, $cari) . "%'";
}
$sql .= " ORDER BY p.id_produk DESC";
$result = mysqli_query($koneksi, $sql);
?>

<main class="admin-main">
  <div class="admin-topbar">
    <div>
      <h2 style="font-size: 20px; font-weight: 800; color: var(--navy);">Kelola Produk Camilan</h2>
      <p style="font-size: 13px; color: var(--navy-light);">Tambah snack baru, atur harga diskon, deskripsi, dan upload foto</p>
    </div>
    <a href="<?= BASE_URL ?>admin/produk_tambah.php" class="btn btn-primary btn-sm">
      <i class="fa-solid fa-plus"></i> Tambah Produk Baru
    </a>
  </div>

  <div class="admin-body">
    <?= get_flash() ?>

    <div class="card" style="padding: 0; overflow: hidden;">
      <!-- Bar Pencarian -->
      <div style="padding: 16px 20px; background: var(--white); border-bottom: 1px solid var(--border-color); display: flex; justify-content: space-between; align-items: center; flex-wrap: wrap; gap: 15px;">
        <h3 style="font-size: 16px; margin: 0; color: var(--navy);">Semua Daftar Produk (<?= mysqli_num_rows($result) ?>)</h3>
        
        <form action="<?= BASE_URL ?>admin/produk.php" method="GET" style="display: flex; gap: 8px;">
          <input type="text" name="cari" class="form-control" style="width: 240px; padding: 6px 12px; font-size: 13px;" placeholder="Cari nama snack..." value="<?= htmlspecialchars($cari) ?>">
          <button type="submit" class="btn btn-sm btn-light">Cari</button>
          <?php if (!empty($cari)): ?>
            <a href="<?= BASE_URL ?>admin/produk.php" class="btn btn-sm btn-outline">Reset</a>
          <?php endif; ?>
        </form>
      </div>

      <div class="table-responsive">
        <table class="table">
          <thead>
            <tr>
              <th style="width: 60px;">Foto</th>
              <th>Nama Camilan</th>
              <th>Kategori</th>
              <th>Harga Jual</th>
              <th>Berat</th>
              <th>Stok</th>
              <th>Status</th>
              <th style="text-align: center; width: 110px;">Aksi</th>
            </tr>
          </thead>
          <tbody>
            <?php if ($result && mysqli_num_rows($result) > 0): ?>
              <?php while ($p = mysqli_fetch_assoc($result)): ?>
                <tr>
                  <td>
                    <img src="<?= get_product_image_url($p['foto'] ?? '') ?>" 
                         style="width: 50px; height: 50px; object-fit: cover; border-radius: 8px; border: 1px solid var(--border-color); background: var(--soft-gray);"
                         loading="lazy"
                         onerror="this.onerror=null; this.src='<?= BASE_URL ?>assets/images/products/default_snack.jpg';">
                  </td>
                  <td>
                    <strong style="color: var(--navy);"><?= htmlspecialchars($p['nama_produk']) ?></strong>
                    <div style="font-size: 11px; margin-top: 3px;">
                      <?php if (!empty($p['is_best_seller'])): ?>
                        <span style="background: #FEF3C7; color: #D97706; padding: 1px 6px; border-radius: 4px; font-weight: 700;">🔥 Best Seller</span>
                      <?php endif; ?>
                      <?php if (!empty($p['is_promo'])): ?>
                        <span style="background: #FEE2E2; color: #DC2626; padding: 1px 6px; border-radius: 4px; font-weight: 700;">⚡ Promo</span>
                      <?php endif; ?>
                    </div>
                  </td>
                  <td>
                    <span style="background: var(--light-blue); color: var(--primary-blue); font-size: 11px; font-weight: 700; padding: 3px 8px; border-radius: 12px;">
                      <?= htmlspecialchars($p['nama_kategori']) ?>
                    </span>
                  </td>
                  <td>
                    <span style="font-weight: 800; color: var(--primary-blue);"><?= rupiah($p['harga']) ?></span>
                    <?php if (!empty($p['harga_coret']) && $p['harga_coret'] > $p['harga']): ?>
                      <div style="font-size: 11px; color: var(--navy-light); text-decoration: line-through;"><?= rupiah($p['harga_coret']) ?></div>
                    <?php endif; ?>
                  </td>
                  <td><?= $p['berat_gram'] ?> gr</td>
                  <td>
                    <?php if ($p['stok'] < 10): ?>
                      <span style="color: #DC2626; font-weight: 800;"><?= $p['stok'] ?> (Kritis)</span>
                    <?php else: ?>
                      <span style="font-weight: 700;"><?= $p['stok'] ?></span>
                    <?php endif; ?>
                  </td>
                  <td>
                    <a href="<?= BASE_URL ?>admin/produk.php?action=toggle_status&id=<?= $p['id_produk'] ?>" 
                       title="Klik untuk mengubah status: <?= ($p['status'] === 'aktif') ? 'Nonaktifkan' : 'Aktifkan' ?>" 
                       style="text-decoration: none;">
                      <?php if ($p['status'] === 'aktif'): ?>
                        <span style="background: #DCFCE7; color: #16A34A; font-size: 11px; font-weight: 700; padding: 4px 10px; border-radius: 12px; display: inline-flex; align-items: center; gap: 4px; border: 1px solid #86EFAC;">
                          <i class="fa-solid fa-circle-check"></i> Aktif
                        </span>
                      <?php else: ?>
                        <span style="background: #FEE2E2; color: #991B1B; font-size: 11px; font-weight: 700; padding: 4px 10px; border-radius: 12px; display: inline-flex; align-items: center; gap: 4px; border: 1px solid #FCA5A5;">
                          <i class="fa-solid fa-circle-xmark"></i> Nonaktif
                        </span>
                      <?php endif; ?>
                    </a>
                  </td>
                  <td style="text-align: center; white-space: nowrap;">
                    <a href="<?= BASE_URL ?>admin/produk.php?action=toggle_status&id=<?= $p['id_produk'] ?>" 
                       class="btn btn-sm <?= ($p['status'] === 'aktif') ? 'btn-light' : 'btn-primary' ?>" 
                       style="padding: 4px 8px;" 
                       title="<?= ($p['status'] === 'aktif') ? 'Sembunyikan / Nonaktifkan' : 'Tampilkan / Aktifkan' ?>">
                      <i class="fa-solid <?= ($p['status'] === 'aktif') ? 'fa-eye-slash' : 'fa-eye' ?>"></i>
                    </a>
                    <a href="<?= BASE_URL ?>admin/produk_edit.php?id=<?= $p['id_produk'] ?>" class="btn btn-sm btn-light" style="padding: 4px 8px;" title="Edit Snack">
                      <i class="fa-solid fa-pen-to-square"></i>
                    </a>
                    <a href="<?= BASE_URL ?>admin/produk.php?action=hapus&id=<?= $p['id_produk'] ?>" class="btn btn-sm btn-confirm-delete" style="padding: 4px 8px; color: #EF4444;" title="Hapus Snack">
                      <i class="fa-solid fa-trash-can"></i>
                    </a>
                  </td>
                </tr>
              <?php endwhile; ?>
            <?php else: ?>
              <tr>
                <td colspan="8" style="text-align: center; padding: 40px; color: var(--navy-light);">Belum ada produk ditemukan.</td>
              </tr>
            <?php endif; ?>
          </tbody>
        </table>
      </div>
    </div>

<?php require_once __DIR__ . '/includes/footer.php'; ?>
